-- phpMyAdmin SQL Dump
-- version 3.4.11.1deb2+deb7u8
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 14, 2017 at 12:32 AM
-- Server version: 5.5.55
-- PHP Version: 5.4.45-0+deb7u8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `WebDiP2016x077`
--

-- --------------------------------------------------------

--
-- Table structure for table `Bodovi`
--

CREATE TABLE IF NOT EXISTS `Bodovi` (
  `korisnik_korisnik_id` int(10) DEFAULT NULL,
  `bodovna_vrijednost` int(11) DEFAULT NULL,
  `vrijeme_promjene` datetime DEFAULT NULL,
  `povijest_kupovine_id` int(11) DEFAULT NULL,
  KEY `fk_Bodovi_korisnik1` (`korisnik_korisnik_id`),
  KEY `fk_Bodovi_povijest_kupovine1` (`povijest_kupovine_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Bodovi`
--

INSERT INTO `Bodovi` (`korisnik_korisnik_id`, `bodovna_vrijednost`, `vrijeme_promjene`, `povijest_kupovine_id`) VALUES
(6, 200, '2017-06-13 22:21:14', NULL),
(2, 10, '2017-06-13 22:39:15', NULL),
(2, 1, '2017-06-13 22:43:50', NULL),
(6, 10, '2017-06-13 22:47:57', NULL),
(6, 1, '2017-06-13 22:49:45', NULL),
(6, 15, '2017-06-13 22:51:51', NULL),
(6, 2, '2017-06-13 22:57:06', NULL),
(6, 2, '2017-06-13 22:57:14', NULL),
(6, 1, '2017-06-13 23:19:38', NULL),
(2, 10, '2017-06-13 23:24:09', NULL),
(2, 2, '2017-06-13 23:27:12', NULL),
(2, 1, '2017-06-13 23:27:22', NULL),
(3, 10, '2017-06-13 23:27:30', NULL),
(3, 10, '2017-06-13 23:34:15', NULL),
(3, 1, '2017-06-13 23:34:27', NULL),
(3, 10, '2017-06-13 23:38:24', NULL),
(3, 1, '2017-06-13 23:53:11', NULL),
(3, 1, '2017-06-13 23:55:11', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `diskusija`
--

CREATE TABLE IF NOT EXISTS `diskusija` (
  `diskusija_id` int(11) NOT NULL AUTO_INCREMENT,
  `datum_kreiranja` datetime DEFAULT NULL,
  `datum_zatvaranja` datetime DEFAULT NULL,
  `podrucje_interesa_id` int(11) NOT NULL,
  `pravila` varchar(100) DEFAULT NULL,
  `pravo_komentiranja` tinyint(4) DEFAULT NULL,
  `naziv_diskusije` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`diskusija_id`,`podrucje_interesa_id`),
  KEY `fk_diskusija_podrucje_interesa1_idx` (`podrucje_interesa_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `diskusija`
--

INSERT INTO `diskusija` (`diskusija_id`, `datum_kreiranja`, `datum_zatvaranja`, `podrucje_interesa_id`, `pravila`, `pravo_komentiranja`, `naziv_diskusije`) VALUES
(1, '2017-06-12 00:00:00', '2017-09-22 00:00:00', 3, 'Kakvi su laptopi ove serije?', 1, 'Inspiron 15 7000 Series'),
(2, '2017-06-06 00:00:00', '2017-06-30 00:00:00', 4, 'pravilo test', 1, 'diskusija 2'),
(3, '2017-06-06 00:00:00', '2017-06-30 00:00:00', 3, 'pravilo test 3', 1, 'diskusija 3'),
(4, '2017-06-13 21:45:51', '2017-06-30 03:02:00', 2, 'Komentari vezani za kolegije na predmetima', 1, 'Kolegiji');

-- --------------------------------------------------------

--
-- Table structure for table `dnevnik_rada`
--

CREATE TABLE IF NOT EXISTS `dnevnik_rada` (
  `dnevnik_rada_id` int(11) NOT NULL AUTO_INCREMENT,
  `korisnik` varchar(45) DEFAULT NULL,
  `adresa` varchar(200) DEFAULT NULL,
  `opis` varchar(250) DEFAULT NULL,
  `vrijeme` datetime DEFAULT NULL,
  PRIMARY KEY (`dnevnik_rada_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `dnevnik_rada`
--

INSERT INTO `dnevnik_rada` (`dnevnik_rada_id`, `korisnik`, `adresa`, `opis`, `vrijeme`) VALUES
(1, 'neregistrirani korisnik', 'https://barka.foi.hr/WebDiP/2016_projekti/Web', 'Pokusaj otvaranja nedozvoljenje stranice.', '2017-06-11 18:23:43'),
(2, 'moderator', 'https://barka.foi.hr/WebDiP/2016_projekti/WebDiP2016x077/pomak_vremena.php', 'Pokusaj otvaranja nedozvoljenje stranice.', '2017-06-11 18:24:58'),
(3, 'moderator', 'https://barka.foi.hr/WebDiP/2016_projekti/WebDiP2016x077/pomak_vremena.php', 'Pokusaj otvaranja nedozvoljenje stranice.', '2017-06-11 19:26:18'),
(4, 'neregistrirani korisnik', 'https://barka.foi.hr/WebDiP/2016_projekti/WebDiP2016x077/pomak_vremena.php', 'Pokusaj otvaranja nedozvoljenje stranice.', '2017-06-12 22:04:07'),
(5, 'neregistrirani korisnik', 'http://barka.foi.hr/WebDiP/2016_projekti/WebDiP2016x077/kreiranje_podrucja_interesa.php', 'Pokusaj otvaranja nedozvoljenje stranice.', '2017-06-12 22:56:48'),
(6, 'neregistrirani korisnik', 'http://barka.foi.hr/WebDiP/2016_projekti/WebDiP2016x077/popis_komentara.php?diskusija_id=1', 'Pokusaj otvaranja nedozvoljenje stranice.', '2017-06-13 03:29:28'),
(7, 'neregistrirani korisnik', 'http://barka.foi.hr/WebDiP/2016_projekti/WebDiP2016x077/popis_komentara.php?diskusija_id=1', 'Pokusaj otvaranja nedozvoljenje stranice.', '2017-06-13 03:29:29'),
(8, 'neregistrirani korisnik', 'http://barka.foi.hr/WebDiP/2016_projekti/WebDiP2016x077/kreiranje_diskusije.php', 'Pokusaj otvaranja nedozvoljenje stranice.', '2017-06-13 16:42:57'),
(9, 'neregistrirani korisnik', 'http://barka.foi.hr/WebDiP/2016_projekti/WebDiP2016x077/kreiranje_diskusije.php?podrucje=3', 'Pokusaj otvaranja nedozvoljenje stranice.', '2017-06-13 16:43:16'),
(10, 'neregistrirani korisnik', 'http://barka.foi.hr/WebDiP/2016_projekti/WebDiP2016x077/popis_komentara.php', 'Pokusaj otvaranja nedozvoljenje stranice.', '2017-06-13 21:46:26'),
(11, 'neregistrirani korisnik', 'http://barka.foi.hr/WebDiP/2016_projekti/WebDiP2016x077/kreiranje_diskusije.php?podrucje=5', 'Pokusaj otvaranja nedozvoljenje stranice.', '2017-06-13 21:52:40'),
(12, 'neregistrirani korisnik', 'http://barka.foi.hr/WebDiP/2016_projekti/WebDiP2016x077/kreiranje_diskusije.php', 'Pokusaj otvaranja nedozvoljenje stranice.', '2017-06-13 21:52:49'),
(13, 'neregistrirani korisnik', 'http://barka.foi.hr/WebDiP/2016_projekti/WebDiP2016x077/kreiranje_diskusije.php', 'Pokusaj otvaranja nedozvoljenje stranice.', '2017-06-13 21:53:15'),
(14, 'neregistrirani korisnik', 'http://barka.foi.hr/WebDiP/2016_projekti/WebDiP2016x077/popis_komentara.php', 'Pokusaj otvaranja nedozvoljenje stranice.', '2017-06-13 21:55:03'),
(15, 'neregistrirani korisnik', 'https://barka.foi.hr/WebDiP/2016_projekti/WebDiP2016x077/korisnik_profil.php', 'Pokusaj otvaranja nedozvoljenje stranice.', '2017-06-13 23:38:15');

-- --------------------------------------------------------

--
-- Table structure for table `izgled_podrucja`
--

CREATE TABLE IF NOT EXISTS `izgled_podrucja` (
  `izgled_id` int(11) NOT NULL,
  `boja_pozadine` varchar(45) DEFAULT NULL,
  `font_stil` varchar(45) DEFAULT NULL,
  `velicina_font` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`izgled_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `izgled_podrucja`
--

INSERT INTO `izgled_podrucja` (`izgled_id`, `boja_pozadine`, `font_stil`, `velicina_font`) VALUES
(0, '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `komentar`
--

CREATE TABLE IF NOT EXISTS `komentar` (
  `komentar_id` int(11) NOT NULL AUTO_INCREMENT,
  `diskusija_diskusija_id` int(11) NOT NULL,
  `korisnik_korisnik_id` int(10) NOT NULL,
  `naziv_komentara` varchar(45) DEFAULT NULL,
  `datum_kreiranja` datetime DEFAULT NULL,
  `sadrzaj_komentara` text,
  PRIMARY KEY (`komentar_id`,`diskusija_diskusija_id`,`korisnik_korisnik_id`),
  KEY `fk_komentar_diskusija1_idx` (`diskusija_diskusija_id`),
  KEY `fk_komentar_korisnik1_idx` (`korisnik_korisnik_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `komentar`
--

INSERT INTO `komentar` (`komentar_id`, `diskusija_diskusija_id`, `korisnik_korisnik_id`, `naziv_komentara`, `datum_kreiranja`, `sadrzaj_komentara`) VALUES
(1, 1, 2, 'test', '0000-00-00 00:00:00', 'Test1 Test2'),
(12, 1, 2, 'wrtwr', '2017-06-13 06:45:59', 'wrtwer'),
(13, 1, 2, 'test', '2017-06-13 07:26:06', 'test'),
(14, 1, 2, 'test', '2017-06-13 07:26:07', 'test'),
(15, 1, 2, 'bug?', '2017-06-13 07:26:35', 'bug?'),
(16, 2, 2, 'komentar?', '2017-06-13 07:29:02', 'neki komentar'),
(17, 3, 2, 'opet ', '2017-06-13 07:29:36', 'test'),
(18, 2, 2, 'novi komentar', '2017-06-13 19:16:46', 'nanakav komentar'),
(19, 3, 4, 'test Moderator', '2017-06-13 14:57:01', 'komentar moderator'),
(20, 4, 6, 'Komentar ', '2017-06-13 22:49:45', 'Ninda je bio ovdje'),
(21, 4, 6, 'KOmentar 2', '2017-06-13 22:51:51', 'ninda bodovi test');

-- --------------------------------------------------------

--
-- Table structure for table `korisnik`
--

CREATE TABLE IF NOT EXISTS `korisnik` (
  `korisnik_id` int(10) NOT NULL AUTO_INCREMENT,
  `tip_korisnika_id` int(10) NOT NULL,
  `ime` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `prezime` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `korisnicko_ime` varchar(45) CHARACTER SET utf8 NOT NULL,
  `email` varchar(45) NOT NULL,
  `lozinka` varchar(45) NOT NULL,
  `lozinka_SH` varchar(45) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  `datum_pristupanja` datetime DEFAULT NULL,
  `kolacici_datum` datetime DEFAULT NULL,
  `podrucje_interesa_id` int(11) DEFAULT NULL,
  `datum_zabrane` datetime DEFAULT NULL,
  `neuspjeli_pokusaji` int(11) DEFAULT NULL,
  `aktivacijski_kod` varchar(45) DEFAULT NULL,
  `aktivacijski_kod_vrijeme_trajanja` datetime DEFAULT NULL,
  `prijava_korak_2` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`korisnik_id`),
  KEY `fk_korisnik_tip_korisnika_idx` (`tip_korisnika_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `korisnik`
--

INSERT INTO `korisnik` (`korisnik_id`, `tip_korisnika_id`, `ime`, `prezime`, `korisnicko_ime`, `email`, `lozinka`, `lozinka_SH`, `status`, `datum_pristupanja`, `kolacici_datum`, `podrucje_interesa_id`, `datum_zabrane`, `neuspjeli_pokusaji`, `aktivacijski_kod`, `aktivacijski_kod_vrijeme_trajanja`, `prijava_korak_2`) VALUES
(2, 3, 'Nikola', 'Markotic', 'nmarkoti', 'nmarkoti@foi.hr', 'TEst123', '8b5ca3cb1064151453f1e0a4a8e9b068b580166d', 1, '0000-00-00 00:00:00', NULL, NULL, NULL, 0, '3391', '2017-06-11 20:24:41', 0),
(3, 1, 'Davor', 'Vučina', 'dvucina', 'dvucina@foi.hr', 'DDaa66', 'aef172f51aad2462f6f5935a1b59326d9d60026d', 1, '2017-06-10 14:42:39', NULL, NULL, NULL, 0, '1497098558dvucina', '2017-06-10 19:42:39', 0),
(4, 2, 'Moderator', 'Moderator', 'moderator', 'alokin.markotic@gmail.com', 'MOderator1', '1ae0e6ba911a82bbac02d072e2b52e9b812f9aa5', 1, '2017-06-11 14:49:07', NULL, NULL, NULL, 0, '1497185347moderator', '2017-06-11 19:49:07', 0),
(5, 3, 'korisnik1', 'korisnik1', 'korisnik1', 'xupixaro@refurhost.com', 'AAaa1', '3a351e29d7c446c9845e2b1b14348b50432a2df2', 1, '2017-06-11 19:53:09', NULL, NULL, NULL, 0, '1497199988korisnik1', '2017-06-12 00:53:09', 0),
(6, 3, 'Ninda', 'Adnin', 'ninda', 'mutinodup@micsocks.net', 'NInda1', '9d552a6e3f7cc4d2571113c940b01abbf66a5ce3', 1, '2017-06-13 22:21:14', NULL, NULL, NULL, 0, '1497385273ninda', '2017-06-14 03:21:14', 0);

-- --------------------------------------------------------

--
-- Table structure for table `korisnik_has_podrucje_interesa`
--

CREATE TABLE IF NOT EXISTS `korisnik_has_podrucje_interesa` (
  `korisnik_korisnik_id` int(10) NOT NULL,
  `podrucje_interesa_podrucje_interesa_id` int(11) NOT NULL,
  `moderator` tinyint(4) NOT NULL,
  PRIMARY KEY (`korisnik_korisnik_id`,`podrucje_interesa_podrucje_interesa_id`),
  KEY `fk_korisnik_has_podrucje_interesa_podrucje_interesa1_idx` (`podrucje_interesa_podrucje_interesa_id`),
  KEY `fk_korisnik_has_podrucje_interesa_korisnik1_idx` (`korisnik_korisnik_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `korisnik_has_podrucje_interesa`
--

INSERT INTO `korisnik_has_podrucje_interesa` (`korisnik_korisnik_id`, `podrucje_interesa_podrucje_interesa_id`, `moderator`) VALUES
(2, 3, 0),
(3, 1, 0),
(4, 1, 1),
(4, 2, 1),
(4, 3, 1),
(4, 4, 1),
(4, 5, 1),
(6, 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `korisnik_obavijest`
--

CREATE TABLE IF NOT EXISTS `korisnik_obavijest` (
  `Obavijest_obavijest_id` int(11) NOT NULL,
  `korisnik_korisnik_id` int(10) NOT NULL,
  PRIMARY KEY (`Obavijest_obavijest_id`,`korisnik_korisnik_id`),
  KEY `fk_korisnik_obavijest_korisnik1_idx` (`korisnik_korisnik_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `kupon`
--

CREATE TABLE IF NOT EXISTS `kupon` (
  `kupon_id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(45) DEFAULT NULL,
  `datum_kreiranja` datetime DEFAULT NULL,
  `podrucje_interesa_id` int(11) NOT NULL,
  `bodovna_vrijednost` int(11) DEFAULT NULL,
  `kod` varchar(25) DEFAULT NULL,
  `datum_pocetka_aktivnosti` datetime DEFAULT NULL,
  `datum_zavrsetka_aktivnosti` datetime DEFAULT NULL,
  `lokacija_slika` varchar(45) DEFAULT NULL,
  `lokacija_video` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`kupon_id`,`podrucje_interesa_id`),
  KEY `fk_kupon_podrucje_interesa1_idx` (`podrucje_interesa_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `Obavijest`
--

CREATE TABLE IF NOT EXISTS `Obavijest` (
  `obavijest_id` int(11) NOT NULL AUTO_INCREMENT,
  `sadrzaj_obavijesti` text,
  `status` varchar(45) DEFAULT NULL,
  `korisnik_korisnik_id` int(10) NOT NULL,
  `naslov_obavijesti` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`obavijest_id`,`korisnik_korisnik_id`),
  KEY `fk_Obavijest_korisnik1_idx` (`korisnik_korisnik_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `podrucje_interesa`
--

CREATE TABLE IF NOT EXISTS `podrucje_interesa` (
  `podrucje_interesa_id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv` varchar(50) DEFAULT NULL,
  `datum_kreiranja` datetime DEFAULT NULL,
  `izgled_podrucja_izgled_id` int(11) NOT NULL,
  PRIMARY KEY (`podrucje_interesa_id`),
  KEY `fk_podrucje_interesa_izgled_podrucja1_idx` (`izgled_podrucja_izgled_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `podrucje_interesa`
--

INSERT INTO `podrucje_interesa` (`podrucje_interesa_id`, `naziv`, `datum_kreiranja`, `izgled_podrucja_izgled_id`) VALUES
(1, 'Sport', '2017-06-12 23:18:48', 0),
(2, 'FOI', '2017-06-12 23:18:56', 0),
(3, 'Dell laptop', '2017-06-13 00:18:40', 0),
(4, 'WebDiP', '2017-06-13 00:18:52', 0),
(5, 'Igre', '2017-06-13 00:19:52', 0);

-- --------------------------------------------------------

--
-- Table structure for table `povijest_kupovine`
--

CREATE TABLE IF NOT EXISTS `povijest_kupovine` (
  `korisnik_korisnik_id` int(10) NOT NULL,
  `kupon_kupon_id` int(11) NOT NULL,
  `datum` datetime DEFAULT NULL,
  `povijest_kupovine_id` int(11) NOT NULL,
  PRIMARY KEY (`povijest_kupovine_id`),
  KEY `fk_korisnik_has_kupon_kupon1_idx` (`kupon_kupon_id`),
  KEY `fk_korisnik_has_kupon_korisnik1_idx` (`korisnik_korisnik_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pravo_pristupa`
--

CREATE TABLE IF NOT EXISTS `pravo_pristupa` (
  `pravo_pristupa_id` int(11) NOT NULL AUTO_INCREMENT,
  `korisnik_korisnik_id` int(10) NOT NULL,
  `diskusija_diskusija_id` int(11) NOT NULL,
  PRIMARY KEY (`pravo_pristupa_id`,`korisnik_korisnik_id`,`diskusija_diskusija_id`),
  KEY `fk_pravo_pristupa_korisnik1_idx` (`korisnik_korisnik_id`),
  KEY `fk_pravo_pristupa_diskusija1_idx` (`diskusija_diskusija_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tip_korisnika`
--

CREATE TABLE IF NOT EXISTS `tip_korisnika` (
  `tip_korisnika_id` int(11) NOT NULL AUTO_INCREMENT,
  `naziv_tipa` varchar(45) NOT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`tip_korisnika_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tip_korisnika`
--

INSERT INTO `tip_korisnika` (`tip_korisnika_id`, `naziv_tipa`, `status`) VALUES
(1, 'Administrator', 1),
(2, 'Moderator', 1),
(3, 'Registrirani korisnik', 1),
(4, 'Neregistrirani korisnik', 1);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Bodovi`
--
ALTER TABLE `Bodovi`
  ADD CONSTRAINT `fk_Bodovi_korisnik1` FOREIGN KEY (`korisnik_korisnik_id`) REFERENCES `korisnik` (`korisnik_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Bodovi_povijest_kupovine1` FOREIGN KEY (`povijest_kupovine_id`) REFERENCES `povijest_kupovine` (`povijest_kupovine_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `diskusija`
--
ALTER TABLE `diskusija`
  ADD CONSTRAINT `fk_diskusija_podrucje_interesa1` FOREIGN KEY (`podrucje_interesa_id`) REFERENCES `podrucje_interesa` (`podrucje_interesa_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `komentar`
--
ALTER TABLE `komentar`
  ADD CONSTRAINT `fk_komentar_diskusija1` FOREIGN KEY (`diskusija_diskusija_id`) REFERENCES `diskusija` (`diskusija_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_komentar_korisnik1` FOREIGN KEY (`korisnik_korisnik_id`) REFERENCES `korisnik` (`korisnik_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `korisnik`
--
ALTER TABLE `korisnik`
  ADD CONSTRAINT `fk_korisnik_tip_korisnika` FOREIGN KEY (`tip_korisnika_id`) REFERENCES `tip_korisnika` (`tip_korisnika_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `korisnik_has_podrucje_interesa`
--
ALTER TABLE `korisnik_has_podrucje_interesa`
  ADD CONSTRAINT `fk_korisnik_has_podrucje_interesa_korisnik1` FOREIGN KEY (`korisnik_korisnik_id`) REFERENCES `korisnik` (`korisnik_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_korisnik_has_podrucje_interesa_podrucje_interesa1` FOREIGN KEY (`podrucje_interesa_podrucje_interesa_id`) REFERENCES `podrucje_interesa` (`podrucje_interesa_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `korisnik_obavijest`
--
ALTER TABLE `korisnik_obavijest`
  ADD CONSTRAINT `fk_korisnik_obavijest_Obavijest1` FOREIGN KEY (`Obavijest_obavijest_id`) REFERENCES `Obavijest` (`obavijest_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_korisnik_obavijest_korisnik1` FOREIGN KEY (`korisnik_korisnik_id`) REFERENCES `korisnik` (`korisnik_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `kupon`
--
ALTER TABLE `kupon`
  ADD CONSTRAINT `fk_kupon_podrucje_interesa1` FOREIGN KEY (`podrucje_interesa_id`) REFERENCES `podrucje_interesa` (`podrucje_interesa_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `Obavijest`
--
ALTER TABLE `Obavijest`
  ADD CONSTRAINT `fk_Obavijest_korisnik1` FOREIGN KEY (`korisnik_korisnik_id`) REFERENCES `korisnik` (`korisnik_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `podrucje_interesa`
--
ALTER TABLE `podrucje_interesa`
  ADD CONSTRAINT `fk_podrucje_interesa_izgled_podrucja1` FOREIGN KEY (`izgled_podrucja_izgled_id`) REFERENCES `izgled_podrucja` (`izgled_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `povijest_kupovine`
--
ALTER TABLE `povijest_kupovine`
  ADD CONSTRAINT `fk_korisnik_has_kupon_korisnik1` FOREIGN KEY (`korisnik_korisnik_id`) REFERENCES `korisnik` (`korisnik_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_korisnik_has_kupon_kupon1` FOREIGN KEY (`kupon_kupon_id`) REFERENCES `kupon` (`kupon_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `pravo_pristupa`
--
ALTER TABLE `pravo_pristupa`
  ADD CONSTRAINT `fk_pravo_pristupa_korisnik1` FOREIGN KEY (`korisnik_korisnik_id`) REFERENCES `korisnik` (`korisnik_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_pravo_pristupa_diskusija1` FOREIGN KEY (`diskusija_diskusija_id`) REFERENCES `diskusija` (`diskusija_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
