<nav id="izbornik" class="col-med-10 col-big-10">
    <ul>
        <?php
        if (isset($_SESSION['kor_ime'])) {
            echo "<li class = \"paddingBotTop\" style=\"float: right;\">
                    <a href = \"odjava.php\">Odjava</a>
                </li>";
        } else {
            echo "<li class=\"paddingBotTop\">
            <a href=\"registracija.php\">Registracija</a>   
        </li>";
            echo "<li class=\"paddingBotTop\">
            <a href=\"prijava.php\">Prijava</a>   
        </li>";
        }

        if (isset($_SESSION['tip_id'])) {
            if ($_SESSION['tip_id'] == "1") {
                echo "<li class=\"paddingBotTop\">
            <a href=\"pomak_vremena.php\">Pomak vremena</a>   
        </li>";
                echo "<li class=\"paddingBotTop\">
            <a href=\"kreiranje_podrucja_interesa.php\">Kreiraj PI</a>   
        </li>";
            }

            if (isset($_SESSION['kor_ime'])) {
                echo "<li class = \"paddingBotTop\" style=\"float: right;\">
              <a href = \"korisnik_profil.php\">" . $_SESSION['kor_ime'] . "</a></li>";
            }
            #TEST

            /* if (isset($_SESSION['kor_ime'])) {
              echo "<li class = \"paddingBotTop\" style=\"float: right;\">
              <a href = \"odjava.php\">'" . $_SESSION['kor_ime'] . "' kor_id -> '" . $_SESSION['kor_id'] . "'</a></li>";
              } */
        }
        echo "<li class=\"paddingBotTop\">
            <a href=\"popis_podrucja_interesa.php\">Popis PI</a>   
        </li>";
        ?>
    </ul>
</nav>