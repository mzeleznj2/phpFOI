<?php
require('baza.class.php');
include_once './virtualno_vrijeme.class.php';
session_name('prijava_sesija');
session_start();

$veza = new Baza();
$veza->spojiDB();

$vrijeme = new virtualnoVrijeme();
$virtualno_vrijeme = $vrijeme->get_vrijeme();
?>


<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="author" content="Nikola Markotić">
        <meta name="keywords" content="Popis područja interesa stranica">
        <meta name="description" content="Popis područja interesa  stranica">
        <meta name="date" content="02.05.2017.">
        <link href="css/nmarkoti.css" rel="stylesheet" type="text/css" media="screen">
        <title>Popis područja interesa</title>
    </head>
    <body>
        <?php
        include_once './header.php';
        include_once './navigacija.php';
        ?>
        <section id="sekcijaSadrzaj">
            <h2>Popis podrucja interesa</h2>
            <form id="obrazacKreiranjePodrucja" method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>" class="col-med-10 col-big-10">
                <div>
                    <?php
                    echo "<table class='tablePopis col-med-10 col-big-10'>";
                    echo "<colgroup><col class='pripadaPodrucju'></colgroup>";
                    echo "<thead><tr><th>Naziv područja</th></thead>";
                    
                    if (!isset($_SESSION['tip_id'])) {
                        $upit1 = "SELECT diskusija.podrucje_interesa_id, COUNT( komentar.komentar_id ) AS broj_komentara FROM diskusija LEFT JOIN (komentar) ON ( komentar.diskusija_diskusija_id = diskusija.diskusija_id ) GROUP BY (diskusija.podrucje_interesa_id) ORDER BY broj_komentara DESC LIMIT 3";
                        $podrucja_interesa = array();
                        if ($rezultat = $veza->selectDB($upit1)) {
                            while ($row = $rezultat->fetch_assoc()) {
                                $podrucja_interesa[] = $row['podrucje_interesa_id'];
                            }
                        }
                        $upit = "SELECT * from podrucje_interesa WHERE podrucje_interesa_id = " . $podrucja_interesa[0] . " OR podrucje_interesa_id = " . $podrucja_interesa[1] . " OR podrucje_interesa_id = " . $podrucja_interesa[2];
                        if ($rezultat = $veza->selectDB($upit)) {
                            while ($podrucje = $rezultat->fetch_assoc()) {
                                //echo $podrucje['naziv'];
                                echo "<tr><td class='center'><a href='popis_diskusija.php?podrucje=".$podrucje['podrucje_interesa_id']."'>" . $podrucje['naziv'] . "</a></td></tr>";
                            }
                        }
                        echo "</table>";
                    } else {
                        $upit = "SELECT * from podrucje_interesa";
                        if ($rezultat = $veza->selectDB($upit)) {
                            while ($podrucje = $rezultat->fetch_assoc()) {
                                //echo $podrucje['naziv'];
                                echo "<tr><td class='center'><a href='popis_diskusija.php?podrucje=".$podrucje['podrucje_interesa_id']."'>" . $podrucje['naziv'] . "</a></td></tr>";
                            }
                        }
                        echo "</table>";
                    }
                    ?>
                </div>
            </form>
            <div id="greske" style="margin: 0;">
                <?php
                if (isset($greska))
                    echo "<p class=\"center\"><span style=\"color: red;\">" . $greska . "</span></p>";
                ?>
            </div>
        </section>
        <?php
        include_once './footer.php';
        ?>
    </body>

</html>