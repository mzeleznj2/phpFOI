<?php
require('baza.class.php');
include_once './virtualno_vrijeme.class.php';
session_name('prijava_sesija');
session_start();

$veza = new Baza();
$veza->spojiDB();

$vrijeme = new virtualnoVrijeme();
$virtualno_vrijeme = $vrijeme->get_vrijeme();

$greska = "";

if (!isset($_SESSION['tip_id'])) {
    $korisnik = "neregistrirani korisnik";
    $opis = "Pokusaj otvaranja nedozvoljenje stranice.";
    $url = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
    $sql = "INSERT INTO `dnevnik_rada` VALUES (default, '$korisnik', '$url', '$opis', '$virtualno_vrijeme')";
    $veza->updateDB($sql);
    header('Location:prijava.php');
} else if ($_SESSION['tip_id'] == "3") {
    if (isset($_SESSION['kor_ime'])) {
        $korisnik = $_SESSION['kor_ime'];
    }
    $opis = "Pokusaj otvaranja nedozvoljenje stranice.";
    $url = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
    $sql = "INSERT INTO `dnevnik_rada` VALUES (default, '$korisnik', '$url', '$opis', '$virtualno_vrijeme')";
    $veza->updateDB($sql);
    header('Location:popis_diskusija.php');
}

if (isset($_GET['podrucje']) && !empty($_GET['podrucje'])) {
    if (!isset($_SESSION['podrucje_id'])) {
        $_SESSION['podrucje_id'] = $_GET['podrucje'];
    } else {
        if (isset($_GET['podrucje'])) {
            $_SESSION['podrucje_id'] = $_GET['podrucje'];
        }
    }
}

if (isset($_POST['posalji'])) {
    $vrijeme = new virtualnoVrijeme();
    $datum_kreiranja_diskusije = $vrijeme->get_vrijeme();

    if (empty($_POST['naziv'])) {
        $greska .= "Nije unijet naziv!<br>";
    }

    if (empty($_POST['pravilo'])) {
        $greska .= "Nije unijeto pravilo!<br>";
    }

    if (empty($_POST['datumZatvaranja'])) {
        $greska .= "Nije unijet datum zatvaranja!<br>";
    }

    if ($greska == "") {
        $veza = new Baza();
        $vrijeme = new virtualnoVrijeme();
        //$datum_kreiranja_komentara = $vrijeme->get_vrijeme();
        $naziv_diskusije = $_POST['naziv'];
        $sadrzaj_diskusije = $_POST['pravilo'];
        if (empty($_POST['pravoKomentiranja'])) {
            $pravo_komentiranja = 0;
        } else {
            $pravo_komentiranja = $_POST['pravoKomentiranja'];
        }
        $datum_zatvaranja = $_POST['datumZatvaranja'];
        $datum_kreiranja = $vrijeme->get_vrijeme();
        $veza->spojiDB();
        $insert = "insert into diskusija (datum_kreiranja, datum_zatvaranja, podrucje_interesa_id, pravila, pravo_komentiranja,	naziv_diskusije) "
                . "values('" . $datum_kreiranja . "', '" . $datum_zatvaranja . "', '" . $_SESSION['podrucje_id'] . "', '" . $sadrzaj_diskusije . "', '" . $pravo_komentiranja . "', '" . $naziv_diskusije . "')";
        $veza->updateDB($insert);
    }
}

$veza->zatvoriDB();
?>


<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="author" content="Nikola Markotić">
        <meta name="keywords" content="Kreiranje diskusije stranica">
        <meta name="description" content="Kreiranje diskusije stranica">
        <meta name="date" content="02.05.2017.">
        <link href="css/nmarkoti.css" rel="stylesheet" type="text/css" media="screen">
        <title>Kreiranje diskusije</title>
    </head>
    <body>
        <?php
        include_once './header.php';
        include_once './navigacija.php';
        ?>
        <section id="sekcijaSadrzaj">
            <h2>Kreiranje diskusije</h2>
            <form id="obrazacKreiranjePodrucja" method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>" class="col-med-10 col-big-10">
                <div>
                    <label for="naziv" id="labelNaziv">Naziv diskusije</label>
                    <input type="text" id="naziv" name="naziv" maxlength="45">
                </div>
                <div>
                    <p class="marginBotTop" style="margin-top: 0;"><label for="pravilo" id="labelPravilo">Pravilo</label></p>
                    <textarea id="pravilo" name="pravilo" rows="20" placeholder="Ovdje unesite pravilo"></textarea>
                </div>
                <div>
                    <label for="pravoKomentiranja" id="labelPravoKomentiranja">Pravo komentiranja</label>
                    <input type="checkbox" id="pravoKomentiranja" name="pravoKomentiranja" value="1">
                </div>
                <div>
                    <label id="labelDatumZatvaranja" for="datumZatvaranja" >Datum zatvaranja</label>
                    <input id="datumZatvaranja" name="datumZatvaranja" type="datetime-local">
                </div>
                <div>
                    <label>Datum kreiranja</label>
                    <label for="datumKreiranja" id="datumKreiranja"><?php echo $vrijeme->get_vrijeme(); ?></label>
                </div>
                <button id="posalji2" type="submit" name="posalji" value="poslano">Spremi</button>
            </form>
            <div id="greske">
                <?php
                if (isset($greska))
                    echo "<p class=\"center\"><span style=\"color: red;\">" . $greska . "</span></p>";
                ?>
            </div>
        </section>
        <?php
        include_once './footer.php';
        ?>
    </body>

</html>