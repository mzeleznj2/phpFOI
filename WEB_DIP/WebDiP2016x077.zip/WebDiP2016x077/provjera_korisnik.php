<?php
require('baza.class.php');

$veza = new Baza();
$veza->spojiDB();
$upit = "SELECT * FROM korisnik";
$korisnici = array();
if ($rezultat = $veza->selectDB($upit)) {
    while ($korisnik = $rezultat->fetch_assoc()) {
        $korisnici[] = $korisnik;
    }
} else {
    echo $mysqli->error;
}

header("Content-Type:application/xml");
echo '<?xml version="1.0" encoding="utf-8"?><korisnici>';
$korisnickoIme = $_GET['korisnik'];
$pronaden = 0;
foreach ($korisnici as $korisnik) {
    if ($korisnik['korisnicko_ime'] == $korisnickoIme) {
        $pronaden = 1;
    }
}
echo "<korisnik>$pronaden</korisnik>";
echo "</korisnici>";
?>