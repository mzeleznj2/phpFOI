<?php

function Recaptcha(){
    if(isset($_POST["posalji"])){
        $secret = '6LfEgh8UAAAAAGp9eOH2zFQqYZ-Tkzijav2Ga6Da';
        $response = $_POST["g-recaptcha-response"];
        $remoteip = $_SERVER["REMOTE_ADDR"];
        
        $url = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=$secret&response=$response&remoteip=$remoteip");
        $result = json_decode($url, TRUE);
        //print_r($url);
        if ($result["success"] == 1) {
            return TRUE;
        } 
    }
}

?>
