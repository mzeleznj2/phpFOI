<?php
session_name('prijava_sesija');
session_start();

include_once './baza.class.php';
include_once './sesija.class.php';

?>

<!DOCTYPE html>
<html>

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="author" content="Nikola Markotić">
        <meta name="keywords" content="Početna stranica">
        <meta name="description" content="Početna stranica">
        <meta name="date" content="02.05.2017.">
        <link href="css/nmarkoti.css" rel="stylesheet" type="text/css" media="screen">
        <title>Početna stranica</title>
    </head>
    <body>
        <?php
        include_once './header.php';
        include_once './navigacija.php';
        ?>
        <section id="sekcijaSadrzaj">
            <h2>O autoru</h2>
            <div class="center">
                <figure class="col-med-10 col-big-3 figureFooter2 center marginBotTop">
                    <img src="slike/osnovne/Nikola-mala.jpg" alt="Slika mene" class="center">
                    <figcaption>Slika mene (Nikola Markotić)</figcaption>
                </figure>
                <p>Zovem se Nikola Markotić</p>
                <p>Imam 24 godine, zanima me Web primarno frontend 3D ali dobro je uvijek zanti više!</p>
                <p>Trenutačno radim u jednoj maloj firmi u Varaždinu <a href="http://mtsonline.hr/">MTS</a> kao software developer</p>
            </div>
            <h2>Opis projektnog zadatka</h2>
            <div>
                <h3>Projekt naziva: Povezivanje interesnih skupina</h3>
                <p>Cilj projekta omogućiti korisnicima da međusobno komentiraju i povežu se s obzirom na svoje interese pomoću platforme koja je jednostavna za korištenje.</p>
                <p>Važno je napomenuti da moraju postojati 4 različita tipa korisnika</p>
                <p>Neregistrirani korisnik koji ima najmanju razinu prava, te sukladno tome i najviše zabrana</p>
                <p>Registirani korisnik je korisnik koji prilikom registracije ima mogućnost pretplačivati se na područja koja ga interesiraju i komentirati unutar diskusija koje se nalaze unutar područja koja ga interesiraju.</p>
                <p>Moderator je korisnik koji može kreirati diskusije i moderira područja interesa.</p>
                <p>Administrator je korisnik koji ima najveću razinu ovlati i može manipulirati sa svim ostalim korisnicima i njihovim mogućnostima, područjima interesa i diskusijama.</p>
                <p>U porjektu sam primarno koristio php, js za neke provjere, ajax i xml za dohvaćanje podataka iz baze.</p>
                <p>u izradi projekta sam koristio materijale sa predavanja, kada bi naiša na problem onda bih pretraživao materijale sa zaličitih web mjesta, te sam kao zadnju opciju pitao kolege koji su već bili na kolegiju kako bih dobio bolji uvid.</p>
                <h3>ERA</h3>
                <figure class="col-med-10 col-big-3 figureFooter2 center marginBotTop">
                    <a href="slike/osnovne/ERA-projekt.png"><img src="slike/osnovne/ERA-projekt.png" alt="Slika ERA" class="center"></a>
                    <figcaption>Slika ERE</figcaption>
                </figure>
                <p>Projekt je izvrsen približno oko 50%</p>
            </div>
        </section>
        <?php
        include_once './footer.php';
        ?>
    </body>

</html>