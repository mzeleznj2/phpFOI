<?php
include_once './virtualno_vrijeme.class.php';
include ("baza.class.php");

if (isset($_GET['kod']) && !empty($_GET['kod'])) {
    $upit = "SELECT * FROM korisnik WHERE aktivacijski_kod LIKE '" . $_GET['kod'] . "%';";

    $veza = new Baza();
    $veza->spojiDB();
    $rezultat = $veza->selectDB($upit);

    if (!empty($rezultat) && mysqli_num_rows($rezultat) > 0) {
        $korisnik = mysqli_fetch_object($rezultat);
        //$vrijeme = strtotime("0 Hours");
        $vrijeme = new virtualnoVrijeme();
        $virtualno_vrijeme = $vrijeme->get_vrijeme();

        $upit = "UPDATE korisnik SET status=1 WHERE aktivacijski_kod='" . $_GET['kod'] . "' AND aktivacijski_kod_vrijeme_trajanja > '" . $virtualno_vrijeme . "';";
        $veza->updateDB($upit);
        $veza->zatvoriDB();

        header("Location: prijava.php");
    } else {
        echo "Greska! Aktivacijski link je pogresan!";
    }
}
