<?php

class virtualnoVrijeme {

    private $vrijeme;

    public function get_vrijeme() {
        $filename = 'virtual/virtualno_vrijeme.txt';
        $pomak = file_get_contents($filename);

        $virtualno_vrijeme = date('Y-m-d H:i:s', (time() + ($pomak * 60 * 60)));

        $this->vrijeme = $virtualno_vrijeme;

        return $this->vrijeme;
    }
    
    public function get_vrijeme_minuta($minuta) {
        $filename = 'virtual/virtualno_vrijeme.txt';
        $pomak = file_get_contents($filename);

        $virtualno_vrijeme = date('Y-m-d H:i:s', (time() + ($pomak * 60 * 60) + ($minuta * 60)));

        $this->vrijeme = $virtualno_vrijeme;

        return $this->vrijeme;
    }
    
    public function get_vrijeme_sati($sati) {
        $filename = 'virtual/virtualno_vrijeme.txt';
        $pomak = file_get_contents($filename);

        $virtualno_vrijeme = date('Y-m-d H:i:s', (time() + ($pomak * 60 * 60) + ($sati * 60 * 60)));

        $this->vrijeme = $virtualno_vrijeme;

        return $this->vrijeme;
    }

}
