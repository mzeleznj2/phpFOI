<?php
session_name('prijava_sesija');
session_start();

include_once ("baza.class.php");
include_once ("recaptcha/recaptcha.php");
include_once './virtualno_vrijeme.class.php';

$greska = "";

if (isset($_POST["posalji"])) {

    //Ime
    if (empty($_POST["ime"])) {
        global $greska;
        $greska .= "<p>Ime nije uneseno!</p>";
    }
    if (nedozovljeniZnakovi($_POST["ime"])) {
        global $greska;
        $greska .= "<p>Ime sadrzi nedozvoljene znakove (){}'!#“\/</p>";
    }

    //Prezime
    if (empty($_POST["prezime"])) {
        global $greska;
        $greska .= "<p>Prezime nije uneseno!</p>";
    }
    if (nedozovljeniZnakovi($_POST["prezime"])) {
        global $greska;
        $greska .= "<p>Prezime sadrzi nedozvoljene znakove (){}'!#“\/</p>";
    }

    //Korisnicko ime
    if (empty($_POST["korisnickoIme"])) {
        global $greska;
        $greska .= "<p>Korisnicko ime nije uneseno!</p>";
    }
    if (nedozovljeniZnakovi($_POST["korisnickoIme"])) {
        global $greska;
        $greska .= "<p>Korisnicko ime sadrzi nedozvoljene znakove (){}'!#“\/</p>";
    }

    //Email
    if (empty($_POST["email"])) {
        global $greska;
        $greska .= "<p>Email ime nije unesen!</p>";
    }
    if (nedozovljeniZnakovi($_POST["email"])) {
        global $greska;
        $greska .= "<p>Email ime sadrzi nedozvoljene znakove (){}'!#“\/</p>";
    }
    if (!emailProvjra($_POST["email"])) {
        global $greska;
        $greska .= "<p>Email mora biti oblika nesto@nesto.nesto";
    }

    //Lozinka
    if (empty($_POST["lozinka"])) {
        global $greska;
        $greska .= "<p>Lozinka nije unesena!</p>";
    }
    if (nedozovljeniZnakovi($_POST["lozinka"])) {
        global $greska;
        $greska .= "<p>Lozinka ime sadrzi nedozvoljene znakove (){}'!#“\/</p>";
    }
    if (!lozinkaZnakovi($_POST["lozinka"])) {
        global $greska;
        $greska .= "<p>Lozinka mora biti duga najmanje 5 a najvise 15 znakova, sastoji se minimalno od 2 velika 2 mala slova i jednog broja!</p>";
    }


    //Potvrda lozinke
    if (empty($_POST["lozinkaPotvrda"])) {
        global $greska;
        $greska .= "<p>Potvrda lozinke nije unesena!</p>";
    }
    if (nedozovljeniZnakovi($_POST["lozinkaPotvrda"])) {
        global $greska;
        $greska .= "<p>Potvrda lozinke ime sadrzi nedozvoljene znakove (){}'!#“\/</p>";
    }
    if ($_POST["lozinkaPotvrda"] !== $_POST["lozinka"]) {
        global $greska;
        $greska .= "<p>Lozinka i potvrda nisu iste!</p>";
    }

    //Ostale provjere
    $veza = new Baza();
    $veza->spojiDB();
    $korisnickoIme = $_POST["korisnickoIme"];
    $upitKorisnickoIme = "select * from korisnik where korisnicko_ime='" . $korisnickoIme . "'";
    $odgovorUpitKorisnickoIme = $veza->selectDB($upitKorisnickoIme);

    $email = $_POST["email"];
    $upitEmail = "select * from korisnik where email='" . $email . "'";
    $odgovorUpitEmail = $veza->selectDB($upitEmail);
    $veza->zatvoriDB();

    if (mysqli_num_rows($odgovorUpitKorisnickoIme) > 0) {
        global $greska;
        $greska .= "<p>Korisnik sa tim Korisnickim imenom postoji!</p>";
    }
    if (mysqli_num_rows($odgovorUpitEmail) > 0) {
        global $greska;
        $greska .= "<p>Korisnik sa tom Email adresom postoji!</p>";
    }
    if (!Recaptcha()) {
        global $greska;
        $greska .= "<p>Nije prosla Recaptcha validacija!</p>";
    }

    if (empty($greska)) {
        dodajkorisnika();
    }
}

function nedozovljeniZnakovi($name) {
    $pattern = '/[(){}\'"!#\\/]/';
    $subject = $name;

    if (preg_match($pattern, $subject)) {
        return true;
    }
}

function lozinkaZnakovi($name) {
    $pattern = '/^(?=(.*[A-Z]){2})(?=(.*[a-z]){2})(?=(.*[0-9]){1}).{5,15}$/';
    $subject = $name;

    if (preg_match($pattern, $subject)) {
        return true;
    }
}

function emailProvjra($name) {
    //$pattern = '/^\w{2,}@(\w{2,}\.){1}\w{2,}$/'; stari regEX
    $pattern = '/((\w{2,}\.){0,}\w{2,}){0,}(^\w{2,}){0,1}@(\w{2,}\.){1}\w{2,}$/';
    $subject = $name;

    if (preg_match($pattern, $subject)) {
        return true;
    }
}

function aktivacijskiKod($korisnickoIme) {
    $aktivacijskiKod = (string) time() . $korisnickoIme;
    return $aktivacijskiKod;
}

function posaljiAktivacijskiEmail($kod) {
    $mail_from = "From: Projekt_povezivanje_interesnih_skupina";
    $link = 'http://barka.foi.hr/WebDiP/2016_projekti/WebDiP2016x077/aktivacija.php?kod=' . $kod;
    mail($_POST['email'], 'Aktivacijski kod interesne skupine', $link, $mail_from);
    return $kod;
}

function dodajkorisnika() {
    $veza = new Baza();
    $veza->spojiDB();

    $ime = $_POST['ime'];
    $prezime = $_POST['prezime'];
    $korisnickoIme = $_POST['korisnickoIme'];
    $email = $_POST['email'];
    $lozinka = $_POST['lozinka'];
    $lozinkaSHA1 = sha1($lozinka);
    $prijave = $_POST['prijava'];
    $kod = aktivacijskiKod($korisnickoIme);
    posaljiAktivacijskiEmail($kod);

    $virtualno_vrijeme = new virtualnoVrijeme();

    //$vrijemetrajanjaKoda = strtotime("+5 Hours");
    $vrijemetrajanjaKoda = $virtualno_vrijeme->get_vrijeme_sati(5);
    //$datum_pristupanja = strtotime("+0 Hours");
    $datum_pristupanja = $virtualno_vrijeme->get_vrijeme();

    $korisnikInsert = "insert into korisnik (ime, prezime, korisnicko_ime, email, lozinka, lozinka_SH, prijava_korak_2, tip_korisnika_id, status, aktivacijski_kod, aktivacijski_kod_vrijeme_trajanja, neuspjeli_pokusaji, datum_pristupanja)" . "values ('" . $ime . "', '" . $prezime . "', '" . $korisnickoIme . "', '" . $email . "', '" . $lozinka . "', '" . $lozinkaSHA1 . "', '" . $prijave . "', 3, 0, '" . $kod . "', '" . $vrijemetrajanjaKoda . "', 0, '" . $datum_pristupanja . "')";
    $veza->updateDB($korisnikInsert);
    $upitZadnjiKorisnik = "SELECT * from korisnik ORDER BY korisnik_id DESC LIMIT 1";
    $rezultat = $veza->selectDB($upitZadnjiKorisnik);

    $korisnik = [];
    if (!empty($rezultat) && mysqli_num_rows($rezultat) > 0) {
        $red = mysqli_fetch_object($rezultat);
        $korisnik = ['korisnicko_ime' => $red->korisnicko_ime, 'korisnik_id' => $red->korisnik_id, 'email' => $red->email];
        
        $insertBodovi = "insert into Bodovi (korisnik_korisnik_id, bodovna_vrijednost, vrijeme_promjene)"
        . " values ('".$korisnik['korisnik_id']."', 200, '".$virtualno_vrijeme->get_vrijeme()."')";
        $veza->updateDB($insertBodovi);
    }
    return $korisnik;

    $veza->zatvoriDB();
}
?>

<!DOCTYPE html>
<html>

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="author" content="Nikola Markotić">
        <meta name="keywords" content="Registracija stranica">
        <meta name="description" content="Registracija stranica">
        <meta name="date" content="29.04.2017.">
        <link href="css/nmarkoti.css" rel="stylesheet" type="text/css" media="screen">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
        <script type="text/javascript" src="js/nmarkoti.js"></script>
        <script src='https://www.google.com/recaptcha/api.js'></script>
        <title>Registracija</title>
    </head>
    <body onload="provjera()">
        <?php
        include_once './header.php';
        include_once './navigacija.php';
        ?>
        <section id="sekcijaSadrzaj" class="col-med-10 col-big-10">
            <h2>Obrazac Registracije</h2>
            <div id="greska"><?php echo $greska; ?></div>
            <div>
                <form id="obrazacRegistracija" method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>" class="col-med-10 col-big-10">
                    <div>
                        <label for="ime" id="labelIme">Ime</label>
                        <input type="text" id="ime" name="ime">
                    </div>
                    <div>
                        <label for="prezime" id="labelPrezime">Prezime</label>
                        <input type="text" id="prezime" name="prezime">
                    </div>
                    <div>
                        <label for="korisnickoIme" id="labelKorisnickoIme">Korisničko ime</label>
                        <input type="text" id="korisnickoIme" name="korisnickoIme">
                    </div>
                    <div>
                        <label for="email" id="labelaEmail">E-mail</label>
                        <input type="email" id="email" name="email">
                    </div>
                    <div>
                        <label for="lozinka" id="labelLozinka">Lozinka</label>
                        <input type="password" id="lozinka" name="lozinka">
                    </div>
                    <div>
                        <label for="lozinkaPotvrda" id="labelLozinkaPotvrda">Potvrda Lozinke</label>
                        <input type="password" id="lozinkaPotvrda" name="lozinkaPotvrda">
                    </div>
                    <div>
                        <label for="prijava"><b>Opcije prijave</b></label>
                        <div style="margin-left: 10%; padding-right: 10%;"><input type="radio" id="prijava" name="prijava" value="0" checked="checked">Jedan korak</div>
                        <div style="margin-left: 10%; padding-right: 10%;"><input type="radio" id="prijava1" name="prijava" value="1">Dva koraka</div>
                    </div>
                    <div class="g-recaptcha" data-sitekey="6LfEgh8UAAAAAHbBYpuLljrxUM1XTkO9d_hkQTlg" style="text-align: center;"></div>
                    <div>
                        <button id="posalji2" type="submit" name="posalji" value="posalji">Pošalji</button>
                    </div>
                </form>
            </div>
            <!-- Zezancija -->
            <!-- <div class="center">
                 <iframe width="560" height="315" src="https://www.youtube.com/embed/q2TXbRwYIio?rel=0&autoplay=1" frameborder="0" allowfullscreen></iframe></div>-->
        </section>
        <?php
        include_once './footer.php';
        ?>
    </body>

</html>