<?php
require('baza.class.php');
include_once './virtualno_vrijeme.class.php';
session_name('prijava_sesija');
session_start();

$veza = new Baza();
$veza->spojiDB();

$vrijeme = new virtualnoVrijeme();
$virtualno_vrijeme = $vrijeme->get_vrijeme();

if (!isset($_SESSION['tip_id'])) {
    $korisnik = "neregistrirani korisnik";
    $opis = "Pokusaj otvaranja nedozvoljenje stranice.";
    $url = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
    $sql = "INSERT INTO `dnevnik_rada` VALUES (default, '$korisnik', '$url', '$opis', '$virtualno_vrijeme')";
    $veza->updateDB($sql);
    header('Location:prijava.php');
}


if (isset($_POST['posalji'])) {
    $greska = "";
    $naziv = "";
    $pretplate = [];
    
    if (isset($_POST['pretplata'])) {
        $pretplate = $_POST['pretplata'];
        $N = count($pretplate);
        
        $virtualno_vrijeme = $vrijeme->get_vrijeme();
        $kor_id = $_SESSION['kor_id'];
        //korisnik_korisnik_id	podrucje_interesa_podrucje_interesa_id	moderator
        
        for ($i = 0; $i < $N; $i++) {
            $insert = "INSERT INTO `korisnik_has_podrucje_interesa` VALUES ('$kor_id', '$pretplate[$i]', '0')";
            $veza->updateDB($insert);
        }
        $veza->updateDB($insert);
        
    } else {
        $greska .= "Greska, nije odabrano niti jedno podrucje interesa.";
    }
}
?>


<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="author" content="Nikola Markotić">
        <meta name="keywords" content="Korisnik - uredivanje profila">
        <meta name="description" content="Uredivanje profila; pretplata na podrucja interesa">
        <meta name="date" content="02.05.2017.">
        <link href="css/nmarkoti.css" rel="stylesheet" type="text/css" media="screen">
        <title>Uredivanje profila korisnika</title>
    </head>
    <body>
        <?php
        include_once './header.php';
        include_once './navigacija.php';
        ?>
        <section id="sekcijaSadrzaj">
            <h2>Uredivanje profila korisnika</h2>
            <form id="obrazacKreiranjePodrucja" method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>" class="col-med-10 col-big-10">
                <div>
                    <label for="naziv" id="labelNaziv">Naziv</label>
                    <input type="text" id="naziv" name="naziv">
                </div>
                <div>
                    <?php
                    echo "<table class='tablePopis col-med-10 col-big-10'>";
                    echo "<colgroup><col class='korisnickoIme'><col class='pripada'></colgroup>";
                    echo "<thead><tr><th>Naziv podrucja interesa</th><th>Pretplati se</th></tr></thead>";
                    $upit = "SELECT podrucje_interesa_id, naziv FROM podrucje_interesa";
                    if ($rezultat = $veza->selectDB($upit)) {
                        while ($podrucja_interesa = $rezultat->fetch_assoc()) {
                            //echo $korisnik['korisnicko_ime'];
                            echo "<tr><td class='center'>" . $podrucja_interesa['naziv'] . "</td><td class='center'><input  style='float:none;margin:0;' type='checkbox' name='pretplata[]' value='" . $podrucja_interesa['podrucje_interesa_id'] . "'></td></tr>";
                        }
                    }
                    echo "</table>";
                    ?>
                </div>
                <button id="posalji2" type="submit" name="posalji" value="poslano">Spremi</button>
            </form>
            <div id="greske">
            <?php
            if (isset($greska))
                echo "<p class=\"center\"><span style=\"color: red;\">" . $greska ."</span></p>";
            ?>
            </div>
        </section>
        <?php
        include_once './footer.php';
        ?>
    </body>

</html>