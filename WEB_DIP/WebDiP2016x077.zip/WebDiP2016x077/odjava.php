<?php

session_name('prijava_sesija');
session_start();

include_once('./sesija.class.php');
include_once './virtualno_vrijeme.class.php';
include_once './baza.class.php';

$veza = new Baza();
$veza->spojiDB();

$vrijeme = new virtualnoVrijeme();
$insertBodovi = "insert into Bodovi (korisnik_korisnik_id, bodovna_vrijednost, vrijeme_promjene)"
        . " values ('" . $_SESSION['kor_id'] . "', 1, '" . $vrijeme->get_vrijeme() . "')";
$veza->updateDB($insertBodovi);

$veza->zatvoriDB();

$session = new Sesija();
$session->obrisiSesiju();
$adresa = 'prijava.php';
header("Location: $adresa");
?>