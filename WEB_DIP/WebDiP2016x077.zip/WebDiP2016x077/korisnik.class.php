<?php

include_once './baza.class.php';

class Korisnik {

    private $kor_ime;
    private $ime;
    private $prezime;
    private $lozinka;
    //private $vrsta = 9;
    private $prijavljen_od;
    private $status = 0;
    private $adresa;
    private $kor_id;
    private $tip_id = 4;
    private $email;
    private $kor_status;
    private $neuspjeli_pokusaji;
    private $prijava_korak_2;

    public function Korisnik($kor_ime = NULL) {
        $veza = new Baza();
        $veza->spojiDB();
        $upit = "select korisnik_id, ime, prezime, korisnicko_ime, lozinka, tip_korisnika_id, status, email, neuspjeli_pokusaji, prijava_korak_2, aktivacijski_kod, aktivacijski_kod_vrijeme_trajanja FROM korisnik where korisnicko_ime = '" . $kor_ime . "';";
        $odgovorUpit = $veza->selectDB($upit);
        if (!$odgovorUpit) {
            trigger_error("Problem kod upita na bazu podataka!", E_USER_ERROR);
        }
        list($kor_id, $ime, $prezime, $kor_ime, $lozinka, $tip_id, $kor_status, $email, $neuspjeli_pokusaji, $prijava_korak_2, $aktivacijski_kod, $aktivacijski_kod_vrijeme_trajanja) = $odgovorUpit->fetch_array();
        $this->set_podaci($kor_id, $ime, $prezime, $kor_ime, $lozinka, $tip_id, $kor_status, $email, $neuspjeli_pokusaji, $prijava_korak_2, $aktivacijski_kod, $aktivacijski_kod_vrijeme_trajanja);
        if ($odgovorUpit->num_rows == 0) {
            $this->tip_id = 4;
        }
        $veza->zatvoriDB();
    }

    public function set_podaci($kor_id, $ime, $prezime, $kor_ime, $lozinka, $tip_id, $kor_status, $email, $neuspjeli_pokusaji, $prijava_korak_2, $aktivacijski_kod, $aktivacijski_kod_vrijeme_trajanja) {
        $this->kor_ime = $kor_ime;
        $this->ime = $ime;
        $this->prezime = $prezime;
        $this->lozinka = $lozinka;
        //$this->vrsta = $vrsta;
        $this->prijavljen_od = time();
        $this->status = 0;
        $this->adresa = $_SERVER["REMOTE_ADDR"];

        $this->kor_id = $kor_id;
        $this->tip_id = $tip_id;
        $this->kor_status = $kor_status;
        $this->email = $email;
        $this->neuspjeli_pokusaji = $neuspjeli_pokusaji;
        $this->prijava_korak_2 = $prijava_korak_2;
        $this->aktivacijski_kod = $aktivacijski_kod;
        $this->aktivacijski_kod_vrijeme_trajanja = $aktivacijski_kod_vrijeme_trajanja;
    }

    public function set_status($p_status) {
        $this->status = $p_status;
    }

    public function get_status() {
        return $this->status;
    }

    public function get_kor_ime() {
        return $this->kor_ime;
    }

    public function get_ime_prezime() {
        return $this->ime . " " . $this->prezime;
    }

    public function get_prezime() {
        return $this->prezime;
    }

    public function get_ime() {
        return $this->ime;
    }

    /* public function get_vrsta() {
      return $this->vrsta;
      } */

    public function get_prijavljen_od() {
        return date("d.m.Y H:i:s", $this->prijavljen_od);
    }

    public function get_aktivan() {
        return time() - $this->prijavljen_od;
    }

    public function get_adresa() {
        return $this->adresa;
    }

    public function get_lozinka() {
        return $this->lozinka;
    }

    public function get_kor_id() {
        return $this->kor_id;
    }

    public function get_tip_id() {
        return $this->tip_id;
    }

    public function get_kor_status() {
        return $this->kor_status;
    }

    public function get_email() {
        return $this->email;
    }

    public function get_neuspjeli_pokusaji() {
        return $this->neuspjeli_pokusaji;
    }
    
    public function get_prijava_korak_2(){
        return $this->prijava_korak_2;
    }

    public function get_aktivacijski_kod(){
    return $this->aktivacijski_kod;
    }
    
    public function get_aktivacijski_kod_vrijeme_trajanja(){
        return $this->aktivacijski_kod_vrijeme_trajanja;
    }
}

?>