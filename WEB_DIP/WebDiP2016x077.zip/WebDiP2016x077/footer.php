<footer class="col-med-10 col-big-10 marginBotTop">
    <p class="center">Kontakt: <a href="mailto:nmarkoti@foi.hr" style="color: #333;">Nikola Markotić</a></p>
    <p class="center"><small>&copy;Sva prava pridržana, Web dizajn i programiranje, 2017.</small></p>
            <figure class="col-med-10 col-big-3 figureFooter1 center marginBotTop">
                <a href="http://validator.w3.org/check?uri=http://<?php echo $_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF']?>">
                    <img src="slike/osnovne/HTML5.png" alt="HTML5 validation slika">
                </a>
                <figcaption>Validacija HTML5</figcaption>
            </figure>
            <figure class="col-med-10 col-big-3 figureFooter2 center marginBotTop">
                <a href="http://jigsaw.w3.org/css-validator/check/referer">
                    <img src="slike/osnovne/CSS3.png" alt="CSS3 validation slika">
                </a>
                <figcaption>Validacija CSS3</figcaption>
            </figure>
        </footer>