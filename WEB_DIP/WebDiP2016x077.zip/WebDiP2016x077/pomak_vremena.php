<?php
require('baza.class.php');
session_name('prijava_sesija');
session_start();

$veza = new Baza();
$veza->spojiDB();

$filename = 'virtual/virtualno_vrijeme.txt';
$pomak = file_get_contents($filename);

$virtualno_vrijeme = date('Y-m-d H:i:s', (time() + ($pomak * 60 * 60)));

if (!isset($_SESSION['tip_id'])) {
    $korisnik = "neregistrirani korisnik";
    $opis = "Pokusaj otvaranja nedozvoljenje stranice.";
    $url = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
    $sql = "INSERT INTO `dnevnik_rada` VALUES (default, '$korisnik', '$url', '$opis', '$virtualno_vrijeme')";
    $veza->updateDB($sql);
    header('Location:prijava.php');
} else if ($_SESSION['tip_id'] != "1") {
    if (isset($_SESSION['kor_ime'])) {
        $korisnik = $_SESSION['kor_ime'];
    }
    $opis = "Pokusaj otvaranja nedozvoljenje stranice.";
    $url = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
    $sql = "INSERT INTO `dnevnik_rada` VALUES (default, '$korisnik', '$url', '$opis', '$virtualno_vrijeme')";
    $veza->updateDB($sql);
    header('Location:prijava.php');
}

if (isset($_POST["posalji"])) {
    // XML data
    $url = "http://barka.foi.hr/WebDiP/pomak_vremena/pomak.php?format=xml";
    $xml = simplexml_load_file($url);
    if ($xml === false) {
        $greska = "Greska prilikom ucitavanja virtualnog pomaka (url: " . $url . ").";
    }
    //print_r($xml);
    $pomSati = $xml->vrijeme->pomak->brojSati;

    $virtualno_vrijeme = date('Y-m-d H:i:s', (time() + ($pomSati * 60 * 60)));
    //echo "Stvarno vrijeme: " . $stvarnoVrijeme . "<br>";
    //echo "Virtualno vrijeme: " . $virtualnoVrijeme . "<br>";
    $pomak = $pomSati;

    $myfile = fopen($filename, "w") or die("Unable to open file!");
    fwrite($myfile, $pomSati);
    fclose($myfile);
}
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="author" content="Nikola Markotić">
        <meta name="keywords" content="Kod stranica">
        <meta name="description" content="Kod stranica">
        <meta name="date" content="02.05.2017.">
        <link href="css/nmarkoti.css" rel="stylesheet" type="text/css" media="screen">
        <title>Virtualno vrijeme</title>
    </head>
    <body>
        <?php
        include_once './header.php';
        include_once './navigacija.php';
        ?>
        <section id="sekcijaSadrzaj">
            <h2>Virtualno vrijeme</h2>
            <form id="obrazacKod" method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>" class="col-med-5 col-big-5">
                <div>
                    <label for="labela_pomak">Pomak:</label>
                    <label for="pomak"><?php echo $pomak ?> sat(i)</label>
                </div>
                <div>
                    <label for="labela_virtualno_vrijeme">Virtualno vrijeme:</label>
                    <label for="virtualno_vrijeme"><?php echo $virtualno_vrijeme ?></label>
                </div>
                <button id="posalji" type="submit" name="posalji" value="poslano">Dohvati pomak</button>
            </form>
            <div id="definiraj_pomak" class="col-med-5 col-big-5 center">
                <a class="gumb" href="http://barka.foi.hr/WebDiP/pomak_vremena/vrijeme.html" target="_blank">Definiraj pomak</a>
            </div>
            <div id="greske">
                <?php
                if (isset($greska))
                    echo $greska;
                ?>
            </div>
        </section>
        <?php
        include_once './footer.php';
        ?>
    </body>

</html>