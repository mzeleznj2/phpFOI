<?php
session_name('prijava_sesija');
session_start();

include_once './baza.class.php';
include_once './sesija.class.php';
include_once './virtualno_vrijeme.class.php';

if (isset($_POST["posalji"])) {
    $greska = "";
    $veza = new Baza();
    $veza->spojiDB();
    $kor_ime = $_POST["korisnickoIme"];
    $korisnik = new Korisnik($kor_ime);
    $kod = rand(1000, 9999);
    $mail_from = "From: Projekt_povezivanje_interesnih_skupina";
    mail($korisnik->get_email(), 'Kod prijave u dva koraka', $kod, $mail_from);
    //$vrijeme_trajanja_koda = strtotime("+5 min");

    $vrijeme = new virtualnoVrijeme();
    $vrijeme_trajanja_koda = $vrijeme->get_vrijeme_minuta(5);
    
    $upit = "update korisnik set aktivacijski_kod = '" . $kod . "', aktivacijski_kod_vrijeme_trajanja = '" . $vrijeme_trajanja_koda . "' where korisnicko_ime = '" . $kor_ime . "'";
    $veza->updateDB($upit);
    $veza->zatvoriDB();

    if ($kor_ime == "") {
        $greska .= "<p class=\"center\"><span style=\"color: red;\">Niste unjeli korisničko ime!</span></p>";
    }
    
    if ($greska == "") {
        $greska .= "<p class=\"center\"><span style=\"color: green;\">Poslan kod!</span></p>";
    }
}
?>

<!DOCTYPE html>
<html>

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="author" content="Nikola Markotić">
        <meta name="keywords" content="Kod stranica">
        <meta name="description" content="Kod stranica">
        <meta name="date" content="02.05.2017.">
        <link href="css/nmarkoti.css" rel="stylesheet" type="text/css" media="screen">
        <title>Kod</title>
    </head>
    <body>
        <?php
        include_once './header.php';
        include_once './navigacija.php';
        ?>
        <section id="sekcijaSadrzaj">
            <h2>Obrazac Kod</h2>
            <form id="obrazacKod" method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>" class="col-med-10 col-big-10">
                <div>
                    <label for="korisnickoIme">Korisničko ime</label>
                    <input type="text" id="korisnickoIme" name="korisnickoIme">
                </div>
                <button id="posalji" type="submit" name="posalji" value="poslano">Pošalji Kod</button>
            </form>
            <div id="greske">
                <?php
                if (isset($greska))
                    echo $greska;
                ?>
            </div>
        </section>
        <?php
        include_once './footer.php';
        ?>
    </body>

</html>