<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
</head>
<body>
<?php
require '../baza.class.php';
$veza = new Baza();
$veza->spojiDB();
//korisničko ime, prezime, ime, email, lozinka
$upit = "SELECT korisnicko_ime, prezime, ime, email, lozinka FROM `korisnik`";

if ($rezultat = $veza->selectDB($upit)) {
    while ($korisnik = $rezultat->fetch_assoc()) {
        $korisnici[] = $korisnik;
    }
}

foreach($korisnici as $korisnik)
{
    echo "Korisnicko ime: " . $korisnik['korisnicko_ime'] . '<br>';
    echo "Prezime: " . $korisnik['prezime'] . '<br>';
    echo "Ime: " . $korisnik['ime'] . '<br>';
    echo "Email: " . $korisnik['email'] . '<br>';
    echo "Lozinka: " . $korisnik['lozinka'] . '<br>';
    echo '<br>';
}
?>
</body>
</html>