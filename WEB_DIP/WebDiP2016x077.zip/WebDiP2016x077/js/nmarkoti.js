function provjera(){
    var lozinka = document.getElementById("lozinka");
    var labelLozinka = document.getElementById("labelLozinka");
    var lozinkaPotvrda = document.getElementById("lozinkaPotvrda");
    var labelLozinkaPotvrda = document.getElementById("labelLozinkaPotvrda");
    var ime = document.getElementById("ime");
    var labelIme = document.getElementById("labelIme");
    var prezime = document.getElementById("prezime");
    var labelPrezime = document.getElementById("labelPrezime");
    var korisnickoIme = document.getElementById("korisnickoIme");
    var labelKorisnickoIme = document.getElementById("labelKorisnickoIme");
    var email = document.getElementById("email");
    var labelaEmail = document.getElementById("labelaEmail");
    
    document.getElementById("lozinka").addEventListener("keyup", function(event){
        if (lozinka.value.length < 5) {
            labelLozinka.className = "greska";
        }else if (!noCharacters("lozinka")) {
            labelLozinka.className = "greska";
        }else{
            labelLozinka.className = "";
        }
    });

    document.getElementById("lozinkaPotvrda").addEventListener("keyup", function (event) {
        if (lozinkaPotvrda.value !== lozinka.value) {
            labelLozinkaPotvrda.className = "greska";
        } else if (!noCharacters("lozinkaPotvrda")) {
            labelLozinkaPotvrda.className = "greska";
        } else {
            labelLozinkaPotvrda.className = "";
        }

    });
    
    document.getElementById("ime").addEventListener("keyup", function(event){
        if (!noCharacters("ime")) {
            labelIme.className = "greska";
        }else {
            labelIme.className = "";
        }
    });
    
    document.getElementById("prezime").addEventListener("keyup", function(event){
        if (!noCharacters("prezime")) {
            labelPrezime.className = "greska";
        }else {
            labelPrezime.className = "";
        }
    });
    
    document.getElementById("korisnickoIme").addEventListener("keyup", function(event){
        if (!noCharacters("korisnickoIme")) {
            labelKorisnickoIme.className = "greska";
        }else {
            labelKorisnickoIme.className = "";
        }
    });
    
    document.getElementById("email").addEventListener("keyup", function(event){
        if (!noCharacters("email")) {
            labelaEmail.className = "greska";
        }else {
            labelaEmail.className = "";
        }
    });

    $("#korisnickoIme").on({
        'blur': function () {
            var korisnik = $('#korisnickoIme').val();
            var DivGreska = $('#greska');
            console.log(korisnik);
            $.ajax({
                url: 'provjera_korisnik.php', data: "korisnik=" + korisnik,
                type: 'GET', dataType: 'xml',
                success: function (xml) {
                    var odgovor = $(xml).find('korisnik').text();
                    if (odgovor === "1") {
                        korisnickoIme_zauzeto = true;
                        DivGreska.html("Greska, korisnicko ime je zauzeto!");
                        DivGreska.removeClass().toggleClass('greska');
                        $('#korisnickoIme').removeClass().toggleClass('greska');
                    } else if (odgovor === "0" && korisnik.length !== 0) {
                        DivGreska.html("");
                        $('#korisnickoIme').removeClass();
                        korisnickoIme_zauzeto = false;
                    }
                }
            });
        }
    });
}

function noCharacters (nameElementId) {
    var name = document.getElementById(nameElementId);
    
    var re = new RegExp(/[(){}'"!#\\/]/g);
    var ok = re.test(name.value);
    
    if (ok) {
        return false;
    }else {
        return true;
    }
}