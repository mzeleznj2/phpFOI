<?php
require('baza.class.php');
include_once './virtualno_vrijeme.class.php';
session_name('prijava_sesija');
session_start();

$veza = new Baza();
$veza->spojiDB();

$vrijeme = new virtualnoVrijeme();
$virtualno_vrijeme = $vrijeme->get_vrijeme();
?>


<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="author" content="Nikola Markotić">
        <meta name="keywords" content="Popis diskusija stranica">
        <meta name="description" content="Popis diskusija  stranica">
        <meta name="date" content="02.05.2017.">
        <link href="css/nmarkoti.css" rel="stylesheet" type="text/css" media="screen">
        <title>Popis diskusija</title>
    </head>
    <body>
        <?php
        include_once './header.php';
        include_once './navigacija.php';
        ?>
        <section id="sekcijaSadrzaj">
            <h2>Popis diskusija</h2>
            <form id="obrazacKreiranjePodrucja" method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>" class="col-med-10 col-big-10">
                <div>
                    <?php
                    if (isset($_GET['podrucje']) && !empty($_GET['podrucje'])) {
                        echo "<table class='tablePopis col-med-10 col-big-10'>";
                        echo "<colgroup><col class='pripadaPodrucju'></colgroup>";
                        echo "<thead><tr><th>Naziv područja</th></thead>";
                        //$upit2 = "SELECT count(*) from komentar where diskusija_diskusija_id";
                        $upit = "SELECT * from diskusija where podrucje_interesa_id='" . $_GET['podrucje'] . "'";
                        if ($rezultat = $veza->selectDB($upit)) {
                            if (isset($_SESSION['tip_id'])) {
                                /*if ($_SESSION['tip_id'] == "2" || $_SESSION['tip_id'] == "1") {
                                    while ($diskusija = $rezultat->fetch_assoc()) {
                                        //echo $podrucje['naziv'];
                                        echo "<tr><td class='center'><a href='komentar.php?diskusija_id=".$diskusija['diskusija_id']."'>" . $diskusija['naziv_diskusije'] . "</td></tr>";
                                    }
                                }*/
                                if ($_SESSION['tip_id'] == "3" || $_SESSION['tip_id'] == "2" || $_SESSION['tip_id'] == "1"){
                                    while ($diskusija = $rezultat->fetch_assoc()) {
                                        //echo $podrucje['naziv'];
                                        echo "<tr><td class='center'><a href='popis_komentara.php?diskusija_id=".$diskusija['diskusija_id']."'>" . $diskusija['naziv_diskusije'] . "</td></tr>";
                                    }
                                }
                            } else {
                                $counter = 0;
                                while ($diskusija = $rezultat->fetch_assoc()) {
                                    //echo $podrucje['naziv'];
                                    echo "<tr><td class='center'>" . $diskusija['naziv_diskusije'] . "</td></tr>";
                                    $counter += 1;
                                    if ($counter == 3) {
                                        exit();
                                    }
                                }
                            }
                        }
                        echo "</table>";
                    }
                    ?>
                </div>
                <div class="center">
                    <?php // Diskusije popravak
                    //$upit = "SELECT * from korisnik_has_podrucje_interesa where korisnik_korisnik_id='" . $_SESSION['kor_id'] . "' and podrucje_interesa_podrucje_interesa_id=(SELECT podrucje_interesa_id from diskusija where diskusija_id='" . $_GET['podrucje'] . "')";
                    if (isset($_SESSION['tip_id'])) {
                    $upit = "SELECT * from korisnik_has_podrucje_interesa where korisnik_korisnik_id='" . $_SESSION['kor_id'] . "' and moderator=1 and podrucje_interesa_podrucje_interesa_id='" . $_GET['podrucje'] . "'";
                    $rezultat = $veza->selectDB($upit);
                    $rezultatCount = $rezultat->fetch_assoc();
                    if (count($rezultatCount) != "0") {
                        $temp = "kreiranje_diskusije.php?podrucje=" . $_GET['podrucje'];
                        echo "<a class=\"gumb\" href=$temp>Nova diskusija</a>";
                    }

                    //if (isset($_SESSION['tip_id'])) {
                        if ($_SESSION['tip_id'] == "1") {
                            $temp = "kreiranje_diskusije.php?podrucje=" . $_GET['podrucje'];
                            echo "<a class=\"gumb\" href=$temp>Nova diskusija</a>";
                        }
                    }
                    ?>
                </div>
            </form>
            <div id="greske" style="margin: 0;">
                <?php
                if (isset($greska))
                    echo "<p class=\"center\"><span style=\"color: red;\">" . $greska . "</span></p>";
                ?>
            </div>
        </section>
        <?php
        include_once './footer.php';
        ?>
    </body>

</html>