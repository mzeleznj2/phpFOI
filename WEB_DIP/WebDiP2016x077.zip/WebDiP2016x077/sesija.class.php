<?php

include_once './korisnik.class.php';
include_once './baza.class.php';
include_once './virtualno_vrijeme.class.php';
/*
 * The MIT License
 *
 * Copyright 2014 Matija Novak <matija.novak@foi.hr>.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * 
 * Klasa za upravljanje sa sesijama
 *
 * @author Matija Novak <matija.novak@foi.hr>
 */

class Sesija {

    const KOR_IME = "kor_ime";
    const TIP_ID = "tip_id";
    const GRESKE = "greske";
    const KOSARICA = "kosarica";
    const SESSION_NAME = "prijava_sesija";
    const KOR_ID = "kor_id";
    const EMAIL = "email";
    const IME = "ime";
    const PREZIME = "prezime";
    const COOKIE_NAME = "prijava_cookie";
    const neuspjeli_pokusaji = "neuspjeli_pokusaji";
    const DISKUSIJA_ID = "diskusija_id";
    const PODRUCJE_ID = "podrucje_id";

    public function set_diskusija_id($diskusija_id) {
        $_SESSION[self::DISKUSIJA_ID] = $diskusija_id;
    }

    public function set_podrucje_id($podrucje_id) {
        $_SESSION[self::PODRUCJE_ID] = $podrucje_id;
    }

    static function kreirajSesiju($korisnik, $zapamti) {
        $kor_id = $korisnik->get_kor_id();
        $tip_id = $korisnik->get_tip_id();
        $kor_ime = $korisnik->get_kor_ime();
        $ime = $korisnik->get_ime();
        $prezime = $korisnik->get_prezime();
        $email = $korisnik->get_email();

        session_name(self::SESSION_NAME);

        if (session_id() == "") {
            session_start();
        }

        $_SESSION[self::KOR_ID] = $kor_id;
        $_SESSION[self::TIP_ID] = $tip_id;
        $_SESSION[self::KOR_IME] = $kor_ime;
        $_SESSION[self::IME] = $ime;
        $_SESSION[self::PREZIME] = $prezime;
        $_SESSION[self::EMAIL] = $email;

        if ($zapamti == "Da") {
            self::kreirajCookie(self::COOKIE_NAME, $kor_ime);
        }
    }

    static function kreirajCookie($cookie_name, $cookie_podatak) {
        setcookie($cookie_name, $cookie_podatak);
    }

    static function obrisiCookie($cookie_name) {
        if (isset($_COOKIE[$cookie_name])) {
            unset($_COOKIE[$cookie_name]);
        }
    }

    /* static function kreirajKorisnika($korisnik, $tip, $greske) {
      self::kreirajSesiju();
      $_SESSION[self::KORISNIK] = $korisnik;
      $_SESSION[self::TIP] = $tip;
      $_SESSION[self::GRESKE] = $greske;
      }

      static function kreirajKosaricu($kosarica) {
      self::kreirajSesiju();
      $_SESSION[self::KOSARICA] = $kosarica;
      }

      static function dajKorisnika() {
      self::kreirajSesiju();
      if (isset($_SESSION[self::KORISNIK])) {
      $korisnik = $_SESSION[self::KORISNIK];
      } else {
      return null;
      }
      return $korisnik;
      }

      static function dajKosaricu() {
      self::kreirajSesiju();
      if (isset($_SESSION[self::KOSARICA])) {
      $kosarica = $_SESSION[self::KOSARICA];
      } else {
      return null;
      }
      return $kosarica;
      }
     */

    function autentikacija($kor_ime, $lozinka, $zapamti, $kodProvjera) {
        $korisnik = new Korisnik($kor_ime);
        $status = 0;
        $neuspjeli_pokusaji = $korisnik->get_neuspjeli_pokusaji();
        $veza = new Baza();
        $veza->spojiDB();
        if ($korisnik->get_kor_status() == "1" && $korisnik->get_prijava_korak_2() == "0") {
            if ($korisnik->get_lozinka() == $lozinka) {
                $this->kreirajSesiju($korisnik, $zapamti);
                $vrijeme = new virtualnoVrijeme();
                $status = 1;
                $upit = "update korisnik set neuspjeli_pokusaji = 0 where korisnicko_ime = '" . $kor_ime . "'";
                $veza->updateDB($upit);

                $insertBodovi = "insert into Bodovi (korisnik_korisnik_id, bodovna_vrijednost, vrijeme_promjene)"
                        . " values ('" . $korisnik->get_kor_id() . "', 10, '" . $vrijeme->get_vrijeme() . "')";
                $veza->updateDB($insertBodovi);
            } else {
                if ($neuspjeli_pokusaji < 3) {
                    $neuspjeli_pokusaji += 1;

                    $upit = "update korisnik set neuspjeli_pokusaji = '" . $neuspjeli_pokusaji . "' where korisnicko_ime = '" . $kor_ime . "'";
                    $veza->updateDB($upit);
                    $status = 0;
                } else if ($neuspjeli_pokusaji == 3) {
                    //$vrijemeZabrane = strtotime("+0 Hours");
                    $vrijeme = new virtualnoVrijeme();
                    $vrijemeZabrane = $vrijeme->get_vrijeme();
                    $upit = "update korisnik set status = 0, neuspjeli_pokusaji = 0, datum_zabrane = '" . $vrijemeZabrane . "' where korisnicko_ime = '" . $kor_ime . "'";
                    $veza->updateDB($upit);
                    $status = 7;
                }
            }
        } else if ($korisnik->get_kor_status() == "1" && $korisnik->get_prijava_korak_2() == "1") {
            $vrijeme = new virtualnoVrijeme();
            $sadaVrijeme = $vrijeme->get_vrijeme();

            if ($korisnik->get_lozinka() == $lozinka && $kodProvjera == $korisnik->get_aktivacijski_kod() && $sadaVrijeme <= $korisnik->get_aktivacijski_kod_vrijeme_trajanja()) {
                $this->kreirajSesiju($korisnik, $zapamti);
                $status = 1;
                $upit = "update korisnik set neuspjeli_pokusaji = 0 where korisnicko_ime = '" . $kor_ime . "'";
                $veza->updateDB($upit);
                
                $insertBodovi = "insert into Bodovi (korisnik_korisnik_id, bodovna_vrijednost, vrijeme_promjene)"
                        . " values ('" . $korisnik->get_kor_id() . "', 10, '" . $vrijeme->get_vrijeme() . "')";
                $veza->updateDB($insertBodovi);
            } else {
                if ($neuspjeli_pokusaji < 3) {
                    $neuspjeli_pokusaji += 1;

                    $upit = "update korisnik set neuspjeli_pokusaji = '" . $neuspjeli_pokusaji . "' where korisnicko_ime = '" . $kor_ime . "'";
                    $veza->updateDB($upit);
                    $status = 0;
                } else if ($neuspjeli_pokusaji == 3) {
                    $vrijemeZabrane = $sadaVrijeme;
                    $upit = "update korisnik set status = 0, neuspjeli_pokusaji = 0, datum_zabrane = '" . $vrijemeZabrane . "' where korisnicko_ime = '" . $kor_ime . "'";
                    $veza->updateDB($upit);
                    $status = 7;
                }
            }
            //$status = 2;
        } /* else {
          $status = 7;
          } */



        $korisnik->set_status($status);
        $veza->zatvoriDB();
        return $korisnik;
    }

    /**
     * Odjavljuje korisnika tj. briše sesiju
     */
    static function obrisiSesiju() {
        session_name(self::SESSION_NAME);

        if (session_id() == "") {
            session_start();
        }
        /* if (session_id() != "") {
          session_unset();
          session_destroy();
          } */
        //$kor_id = $_SESSION[self::KOR_ID];
        $kor_ime = $_SESSION[self::KOR_IME];

        session_unset();
        session_destroy();
    }

}
