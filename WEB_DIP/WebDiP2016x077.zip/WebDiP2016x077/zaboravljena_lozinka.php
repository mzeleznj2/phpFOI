<?php
session_name('prijava_sesija');
session_start();

include_once './baza.class.php';
include_once './sesija.class.php';

if (isset($_POST["posalji"])) {
    $greska = "";
    $veza = new Baza();
    $veza->spojiDB();
    $kor_ime = $_POST["korisnickoIme"];
    $korisnik = new Korisnik($kor_ime);
    $lozinka = rand(100000, 99999999);
    $lozinkaSHA1 = sha1($lozinka);
    $mail_from = "From: Projekt_povezivanje_interesnih_skupina";
    mail($korisnik->get_email(), 'Nova lozinka', $lozinka, $mail_from);

    $upit = "update korisnik set lozinka = '" . $lozinka . "', lozinka_SH = '" . $lozinkaSHA1 . "' where korisnicko_ime = '" . $kor_ime . "'";
    $veza->updateDB($upit);
    $veza->zatvoriDB();

    if ($kor_ime == "") {
        $greska .= "<p class=\"center\"><span style=\"color: red;\">Niste unijeli korisničko ime!</span></p>";
    }
    
    if ($greska == "") {
        $greska .= "<p class=\"center\"><span style=\"color: green;\">Poslana Nova lozinka!</span></p>";
    }
}
?>

<!DOCTYPE html>
<html>

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="author" content="Nikola Markotić">
        <meta name="keywords" content="Nova lozinka stranica">
        <meta name="description" content="Nova lozinka stranica">
        <meta name="date" content="02.05.2017.">
        <link href="css/nmarkoti.css" rel="stylesheet" type="text/css" media="screen">
        <title>Nova lozinka</title>
    </head>
    <body>
        <?php
        include_once './header.php';
        include_once './navigacija.php';
        ?>
        <section id="sekcijaSadrzaj">
            <h2>Obrazac Kod</h2>
            <form id="obrazacKod" method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>" class="col-med-10 col-big-10">
                <div>
                    <label for="korisnickoIme">Korisničko ime</label>
                    <input type="text" id="korisnickoIme" name="korisnickoIme">
                </div>
                <button id="posalji" type="submit" name="posalji" value="poslano">Pošalji lozinku</button>
            </form>
            <div id="greske">
                <?php
                if (isset($greska))
                    echo $greska;
                ?>
            </div>
        </section>
        <?php
        include_once './footer.php';
        ?>
    </body>

</html>