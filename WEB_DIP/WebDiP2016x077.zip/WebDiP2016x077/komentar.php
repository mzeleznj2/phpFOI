<?php
session_name('prijava_sesija');
session_start();

include_once './baza.class.php';
include_once './sesija.class.php';
include_once './virtualno_vrijeme.class.php';

$greska = "";

if (!isset($_SESSION['tip_id'])) {
    $korisnik = "neregistrirani korisnik";
    $opis = "Pokusaj otvaranja nedozvoljenje stranice.";
    $url = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
    $sql = "INSERT INTO `dnevnik_rada` VALUES (default, '$korisnik', '$url', '$opis', '$virtualno_vrijeme')";
    $veza->updateDB($sql);
    header('Location:prijava.php');
}

if (isset($_GET['diskusija_id']) && !empty($_GET['diskusija_id'])) {
    if (!isset($_SESSION['diskusija_id'])) {
        $_SESSION['diskusija_id'] = $_GET['diskusija_id'];
    } else {
        if (isset($_GET['diskusija_id'])) {
            $_SESSION['diskusija_id'] = $_GET['diskusija_id'];
        }
    }
}

if (isset($_POST['posalji'])) {
    $vrijeme = new virtualnoVrijeme();
    $datum_kreiranja_komentara = $vrijeme->get_vrijeme();

    if (empty($_POST['nazivKomentara'])) {
        $greska .= "Nije unijet naziv!<br>";
    }

    if (empty($_POST['sadrzaj'])) {
        $greska .= "Nije unijet sadržaj!<br>";
    }

    if ($greska == "") {
        $veza = new Baza();
        $vrijeme = new virtualnoVrijeme();
        $datum_kreiranja_komentara = $vrijeme->get_vrijeme();
        $naziv_komentara = $_POST['nazivKomentara'];
        $sadrzaj_komentara = $_POST['sadrzaj'];
        $veza->spojiDB();
        $insert = "insert into komentar (diskusija_diskusija_id, korisnik_korisnik_id, naziv_komentara, datum_kreiranja, sadrzaj_komentara) "
                . "values('" . $_SESSION['diskusija_id'] . "', '" . $_SESSION['kor_id'] . "', '" . $naziv_komentara . "', '" . $datum_kreiranja_komentara . "', '" . $sadrzaj_komentara . "')";
        $veza->updateDB($insert);

        $insertBodovi = "insert into Bodovi (korisnik_korisnik_id, bodovna_vrijednost, vrijeme_promjene)"
                . " values ('" . $_SESSION['kor_id'] . "', 15, '" . $vrijeme->get_vrijeme() . "')";
        $veza->updateDB($insertBodovi);

        $veza->zatvoriDB();
    }
}
?>

<!DOCTYPE html>
<html>

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="author" content="Nikola Markotić">
        <meta name="keywords" content="Komentar stranica">
        <meta name="description" content="Komentar stranica">
        <meta name="date" content="02.05.2017.">
        <link href="css/nmarkoti.css" rel="stylesheet" type="text/css" media="screen">
        <title>Komentar</title>
    </head>
    <body>
        <?php
        include_once './header.php';
        include_once './navigacija.php';
        ?>
        <section id="sekcijaSadrzaj">
            <h2>Novi komentar</h2>
            <form id="obrazacKomentar" method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>" class="col-med-10 col-big-10">
                <div>
                    <label for="nazivKomentara">Naziv komentara</label>
                    <input type="text" id="nazivKomentara" name="nazivKomentara" size="45" maxlength="45">
                </div>
                <div>
                    <p class="marginBotTop" style="margin-top: 0;"><label for="sadrzaj">Sadržaj komentara</label></p>
                    <textarea id="sadrzaj" name="sadrzaj" rows="20" placeholder="Ovdje unesite sadržaj"></textarea>
                </div>
                <button id="posalji2" type="submit" name="posalji" value="poslano" class="center">Pošalji</button>
            </form>
            <div id="greske">
                <?php
                if (isset($greska))
                    echo "<p class=\"center\"><span style=\"color: red;\">" . $greska . "</span></p>";
                ?>

            </div>
        </section>
        <?php
        include_once './footer.php';
        ?>
    </body>

</html>