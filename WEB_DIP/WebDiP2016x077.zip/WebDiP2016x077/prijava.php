<?php
session_name('prijava_sesija');
session_start();

if ($_SERVER["HTTPS"] != "on") {
    header("Location: https://" . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]);
    exit();
}

include_once './baza.class.php';
include_once './sesija.class.php';

if (isset($_POST["posalji"])) {

    $korisnickoIme = $_POST["korisnickoIme"];
    $lozinka = $_POST["lozinka"];
    $zapamtiMe = $_POST["zapamtiMe"];
    $kod = $_POST["prijavaDvaKoraka"];
    $session = new Sesija();
    $greska = "";

    $korisnik = $session->autentikacija($korisnickoIme, $lozinka, $zapamtiMe, $kod);

    if ($korisnik->get_status() == 1) {
        $prosljedi = 'registracija.php';
        header("Location: $prosljedi");
        exit();
    } else if ($korisnik->get_status() == 7) {
        $greska .= "Račun je blokiran!<br>";
    } else if ($korisnik->get_status() == 0) {
        $greska .= "Kriva lozinka!";
    }
}
?>

<!DOCTYPE html>
<html>

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="author" content="Nikola Markotić">
        <meta name="keywords" content="Prijava stranica">
        <meta name="description" content="Prijava stranica">
        <meta name="date" content="02.05.2017.">
        <link href="css/nmarkoti.css" rel="stylesheet" type="text/css" media="screen">
        <title>Prijava</title>
    </head>
    <body>
        <?php
        include_once './header.php';
        include_once './navigacija.php';
        ?>
        <section id="sekcijaSadrzaj">
            <h2>Obrazac Prijave</h2>
            <form id="obrazacPrijava" method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>" class="col-med-5 col-big-5">
                <div id="korisnickoImePozicija">
                    <label for="korisnickoIme">Korisničko ime</label>
                    <input type="text" id="korisnickoIme" name="korisnickoIme"
                    <?php
                    if (isset($_COOKIE["prijava_cookie"])) {
                        echo " value=\"" . $_COOKIE['prijava_cookie'] . "\"";
                    } else {
                        echo " placeholder=\"Korisničko ime\" autofocus=\"autofocus\"";
                    }
                    ?>
                           >
                </div>
                <div id="lozinkaPozicija">
                    <label for="lozinka">Lozinka</label>
                    <input type="password" id="lozinka" name="lozinka">
                </div>
                <div id="prijava_Dva_Koraka">
                    <label for="prijavaDvaKoraka">Prijava u dva koraka</label>
                    <input type="number" id="prijavaDvaKoraka" name="prijavaDvaKoraka">
                </div>
                <div id="zapamtiMePozicija">
                    <label>Zapamti me</label>
                    <input type="radio" id="zapamtiMeDa" name="zapamtiMe" value="Da" checked>Da
                    <input type="radio" id="zapamtiMeNE" name="zapamtiMe" value="Ne">Ne
                </div>
                <button id="posalji" type="submit" name="posalji" value="poslano">Pošalji</button>
            </form>
            <div class="col-med-5 col-big-5">
                <div class="center">
                    <a id="prijava_dva_koraka" class="gumb" href="prijavaDvaKoraka.php" target="_blank">Kod dva koraka</a>
                </div>
                <div class="center">
                    <a id="zaboravljena_lozinka" class="gumb" href="zaboravljena_lozinka.php" target="_blank">Zaboravili ste lozinku?</a>
                </div>
            </div>
            <div id="greske">
                <?php
                if (isset($greska))
                    echo "<p class=\"center\"><span style=\"color: red;\">".$greska."</span></p>";
                ?>
            </div>
        </section>
        <?php
        include_once './footer.php';
        ?>
    </body>

</html>