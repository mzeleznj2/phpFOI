<?php

include 'baza_class.php';
$error = null;

if (isset($_POST['login'])) {

    $upit = "SELECT * from korisnik WHERE korisnicko_ime='" . $_POST['korime'] . "' AND lozinka='" . $_POST['lozinka'] . "';";
    $baza = new Baza();
    $baza->spojiDB();

    $rezultat = $baza->selectDB($upit);
    $baza->zatvoriDB();

    if (mysqli_num_rows($rezultat) > 0) {
        while ($red = mysqli_fetch_object($rezultat)) {
            setcookie('loginCookie', $red->id_korisnik, time() + (86400 * 30), "/");
            header("Location:ispis_korisnika.php");
        }
    } else {
        $error = "Krivi pristupni podaci";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title> Zadaća 4 - Prijava</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Maja Zeleznjak">
    <meta name="keywords" content="FOI, WebDiP">
    <link rel="stylesheet" type="text/css" href="css/mzeleznj2.css"/>
    <style type="text/css">
        form {
            background-color: #DDDDDD;
            width: 50%;
            padding: 10px 30px;
            border-radius: 5px;
            margin-top: 10px;
            margin-left: 230px;
        }

        .input1 {
            width: 220px;
            height: 20px;
        }

        .input2 {
            margin: 5px;
            width: 220px;
            height: 20px;
        }

        #label1 {
            color: #000000;
            font-size: 16px;
            width: 100px;
            clear: both;
            height: 20px;
            padding: 3px;
        }

        #label2 {
            color: #000000;
            font-size: 16px;
            width: 100px;
            clear: both;
            height: 20px;
            padding: 3px;
        }

    </style>
</head>
<body>
<section>
    <header>
        <h1> Zadaća 4</h1>
    </header>
</section>
<nav id="meni">
    <ul>
        <li>
            <a href="registracija.php">Registracija</a>
        </li>
        <li>
            <a href="prijava.php">Prijava</a>
        </li>
    </ul>
</nav>
<form id="form1" method="post" name="form1" action="prijava.php">
    <p class="naslov">Prijava</p><br>
    <p>
        <label id="label1" for="korime">Korisničko ime: </label>
        <br>
        <input class="input1" type="text" id="korime" name="korime" placeholder="korisničko ime" autofocus="autofocus"
               autocomplete="off">
        <br>

        <label id="label2" for="lozinka">Lozinka: </label>
        <br>
        <input class="input2" type="password" id="lozinka" name="lozinka" placeholder="lozinka" autocomplete="off">
        <br>
        <br>
        <input type="submit" name="login" value=" Prijavi se">

    <p class="greske">
        <?php echo $error ?>
    </p>

    <p>Korisnik: dMagdalenic_a$123</p>
    <p>Lozinka: Magdalenica#123</p>

    <br>
    <br>
    <p>Registriraj se <a href="registracija.php">ovdje</a></p>
</form>
<footer>
    <a href="http://validator.w3.org/check?uri=http://barka.foi.hr/WebDiP/2015/zadaca_01/mzeleznj2/"><img
            src="img/HTML5.png" height="50" width="50" alt="valid_html"/></a>
    <a href="http://jigsaw.w3.org/css-validator/validator?uri=http://barka.foi.hr/WebDiP/2015/zadaca_01/mzeleznj2"><img
            src="img/CSS3.png" height="50" width="50" alt="valid_css"/> </a>
    <p> Vrijeme potrebno za izradu aktivnog dokumenta: 16h</p>
    <p>&copy; 2016 M.Zeleznjak</p>
</footer>
</body>
</html>