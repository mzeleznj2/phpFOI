<?php

include 'baza_class.php';

if (isset($_COOKIE['loginCookie'])) {

    $tablica = null;
    $upit    = "SELECT * FROM korisnik WHERE ime LIKE '%a%' OR  prezime LIKE '%a%' AND aktiviran = 0;";
    $baza    = new Baza();
    $baza->spojiDB();

    $rezultat = $baza->selectDB($upit);
    $baza->zatvoriDB();

    if (!empty($rezultat) && mysqli_num_rows($rezultat) > 0) {
        $tablica = '<table>
                        <thead>
                        <th>ime</th>
                        <th>Prezime</th>
                        <th>Korisnicko ime</th>
                        <th>Lozinka</th>
                        <th>Adresa</th>
                        <th>Spol</th>
                        <th>Email</th>
                        <th>Lokacija</th>
                        <th>Telefon</th>
                        <th>Akt. kod</th>
                        </thead>
                        <tbody>';
        while ($red = mysqli_fetch_object($rezultat)) {
            $tablica .= '<tr>';
            $tablica .= '<td>' . $red->ime . '</td>';
            $tablica .= '<td>' . $red->prezime . '</td>';
            $tablica .= '<td>' . $red->korisnicko_ime . '</td>';
            $tablica .= '<td>' . $red->lozinka . '</td>';
            $tablica .= '<td>' . $red->adresa . '</td>';
            $tablica .= '<td>' . $red->spol . '</td>';
            $tablica .= '<td>' . $red->email . '</td>';
            $tablica .= '<td>' . $red->lokacija . '</td>';
            $tablica .= '<td>' . $red->mobilni . '</td>';
            $tablica .= '<td>' . $red->aktivacijski_kod . '</td>';
            $tablica .= '</tr>';
        }
        $tablica .= '</tbody></table>';
    }
} else {
    echo "GREŠKA! NEDOZVOLJEN PRISTUP!";
    die();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title> Zadaća 4</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Maja Zeleznjak">
    <meta name="keywords" content="FOI, WebDiP">
    <link rel="stylesheet" type="text/css" href="css/mzeleznj2.css"/>
</head>
<body>
<section>
    <header>
        <h1> Zadaća 4</h1>
    </header>
</section>

<nav id="meni">
    <ul>
        <li>
            <a href="registracija.php">Registracija</a>
        </li>
        <li>
            <a href="prijava.php">Prijava</a>
        </li>
    </ul>
</nav>
<br>
<br>
<?php
echo $tablica;
?>
<br>
<footer>
    <a href="http://validator.w3.org/check?uri=http://barka.foi.hr/WebDiP/2015/zadaca_01/mzeleznj2/"><img
            src="img/HTML5.png" height="50" width="50" alt="valid_html"/></a>
    <a href="http://jigsaw.w3.org/css-validator/validator?uri=http://barka.foi.hr/WebDiP/2015/zadaca_01/mzeleznj2"><img
            src="img/CSS3.png" height="50" width="50" alt="valid_css"/> </a>
    <p> Vrijeme potrebno za izradu aktivnog dokumenta: 16h</p>
    <p>&copy; 2016 M.Zeleznjak</p>
</footer>
</body>
</html>