<?php

include 'baza_class.php';

if (isset($_GET['kod']) && !empty($_GET['kod'])) {

    // u varijablu sada spremamo trenutno vrijeme formata godina-mjesec-dan sat:minuta:sekunda
    // ovdje iz objekta datetime vadis te podatke i samo ih formatiras, ovo new je instanciranje novog objekta a metoda format ti samo to formatira u gore objasnjeni format
    $sada = (new DateTime())->format('Y-m-d h:m:s');

    //ovo ti je upit koji ti traži u bazi koji korisnik ima aktivaicijski kod koji počinje sa kodom kojeg smo primili u get varijabli
    // korisimo like umjesto = jer pošto se šalje u url podaci o aktivaciji, tj taj kod, moguće je da neki od tih znakova bude & koji je dio GET requesta i podaci se gube. na ovaj način si relativno sigurna da će naći korisnika, ovaj drugi dio upita provjerava da li je vrijeme isteklo tj da li su istekla 3 sata od prijave. Ta 3 sata ti se zapisuju u bazu pri registraciji, tj sadasnje vrijeme + 3 sata i onda ovdje gledas ako je vrijeme od ta 3 sata vece od sadasnjeg vremena, onda je taj period istekao i nebi se smjela moci prijaviti putem linka.
    $upit = "SELECT * FROM korisnik WHERE aktivacijski_kod LIKE '" . $_GET['kod'] . "%' AND aktivacija_do > '" . $sada . "' ;";

    // ovo ti je standardni dio svugdje vise manje, dakle instanciras objekt baze i pomocu metoda se spajas na njega i izvrsavas gore napisani upit
    $baza = new Baza();
    $baza->spojiDB();
    $rezultat = $baza->selectDB($upit);

    // provjera koja gleda da li imas rezultata iz baze, odnosno da li upit vraca ista, ako vrati onda ima smisla ici dalje, ako ne onda se ispisuje greska
    if (!empty($rezultat) && mysqli_num_rows($rezultat) > 0) {

        //na ovaj nacin dohvacas rezultate iz baze kao objekte, to mozes raditi na razlicite nacine, mozes tu koristiti recimo mysql_fetch_array koji ti rezultate vraca kao niz, no ja volim ovu sintaksu zato sam tako i radio. dakle dohvati ti rezultat iz baze o spremi ga kao objekt u varijablu korisnik tako da mozes s njim raditi kao s objektom, (koristiti -> umjesto [''] kako bi radila da je niz)
        $korisnik = mysqli_fetch_object($rezultat);

        // ovo je upit koji ti aktivira korisnika, posavlja mu ravijablu aktiviran
        $upit = "UPDATE korisnik set aktiviran=1 WHERE aktivacijski_kod='" . $_GET['kod'] . "' AND korisnik_id=" . $korisnik->id_korisnik . " ;";
        $baza->updateDB($upit);
        $baza->zatvoriDB();

        // ovdje redirectamo korisnika na skriptu s njegovim detaljima i saljemo njegov id u urlu
        header("Location:detalji_korisnika.php?korisnik=" . $korisnik->id_korisnik . "&uspjeh=true");
    } else {
        echo "GREŠKA! Aktivacijski link je pogrešan ili je istekao";
    }
}