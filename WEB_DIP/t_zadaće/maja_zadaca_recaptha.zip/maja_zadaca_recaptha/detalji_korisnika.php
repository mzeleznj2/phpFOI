<?php
include 'baza_class.php';

$korisnik = null;
if (isset($_GET['uspjeh']) && isset($_GET['korisnik'])) {
    $upit = "SELECT * FROM korisnik WHERE id_korisnik=" . $_GET['korisnik'] . " ;";

    $baza = new Baza();
    $baza->spojiDB();

    $rezultat = $baza->selectDB($upit);
    if (!empty($rezultat)) {
        $korisnik = mysqli_fetch_object($rezultat);
    }
}

?>
<!DOCTYPE html>
<html>
<head>
    <title> Zadaća 4</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Maja Zeleznjak">
    <meta name="keywords" content="FOI, WebDiP">
    <link rel="stylesheet" type="text/css" href="css/mzeleznj2.css"/>
</head>
<body>
<section>
    <header>
        <h1> Zadaća 4 </h1>
    </header>
</section>

<nav id="meni">
    <ul>
        <li>
            <a href="registracija.php">Registracija</a>
        </li>
        <li>
            <a href="prijava.php">Prijava</a>
        </li>
    </ul>
</nav>

<div class="div1">
    <?php
    if (isset($_GET['uspjeh'])) {
        echo "<h1>Korisnik aktiviran!</h1>";
    }
    ?>
    <form action="" method="POST">
        <label for="ime"> Ime </label>
        <input class="input2" type="text" id="ime" name="ime" placeholder="ime" value="<?php echo $korisnik->ime ?>"
               autocomplete="off"><br>

        <label for="prezime">Prezime</label>
        <input class="input1" type="text" id="prezime" name="prezime" placeholder="Prezime" autocomplete="off"
               value="<?php echo $korisnik->prezime ?>"><br>

        <label for="korime">Korisničko ime</label>
        <input class="input3" type="text" id="korime" name="korime" placeholder="korime" autofocus="autofocus"
               value="<?php echo $korisnik->korisnicko_ime ?>"><br>

        <label for="lozinka1">Lozinka: </label>
        <input class="input4" type="password" id="lozinka1" name="lozinka1" placeholder="lozinka"
               value="<?php echo $korisnik->lozinka ?>"><br>

        <label class="labelae" for="keygen"> Enkripcija </label>
        <keygen name="keygen" id="keygen" value="<?php echo $korisnik->keygen ?>"><br>
            <br>

            <label class="spol" for="spol">Spol: </label>
            <select id="spol" name="spol">
                <option value="-1" <?php if ($korisnik->spol == -1) echo "selected"; ?>>Odaberi spol</option>
                <option value="M" <?php if ($korisnik->spol == 'M') echo "selected"; ?>>Muškarac</option>
                <option value="Z" <?php if ($korisnik->spol == 'Z') echo "selected"; ?>>Žena</option>
            </select><br>

            <label class="drzava" for="drzava"> Država </label>
            <select id="drzava" name="drzava">
                <option value="-1" <?php if ($korisnik->adresa == -1) echo "selected"; ?>> Odaberi drzavu</option>
                <option value="1" <?php if ($korisnik->adresa == 1) echo "selected"; ?>> Alžir</option>
                <option value="2"<?php if ($korisnik->adresa == 2) echo "selected"; ?>> Austrija</option>
                <option value="3"<?php if ($korisnik->adresa == 3) echo "selected"; ?>> Bosna i Hercegovina</option>
                <option value="4"<?php if ($korisnik->adresa == 4) echo "selected"; ?>> Bugarska</option>
                <option value="5"<?php if ($korisnik->adresa == 5) echo "selected"; ?>> Crna Gora</option>
                <option value="6"<?php if ($korisnik->adresa == 6) echo "selected"; ?>> Čile</option>
                <option value="7"<?php if ($korisnik->adresa == 7) echo "selected"; ?>> Dominikanska republika</option>
                <option value="8"<?php if ($korisnik->adresa == 8) echo "selected"; ?>> Etiopija</option>
                <option value="9"<?php if ($korisnik->adresa == 9) echo "selected"; ?>> Francuska</option>
                <option value="10"<?php if ($korisnik->adresa == 10) echo "selected"; ?>> Fidži</option>
                <option value="11"<?php if ($korisnik->adresa == 11) echo "selected"; ?>> Gana</option>
                <option value="12"<?php if ($korisnik->adresa == 12) echo "selected"; ?>> Hrvatska</option>
                <option value="13"<?php if ($korisnik->adresa == 13) echo "selected"; ?>> Makedonija</option>
                <option value="14"<?php if ($korisnik->adresa == 14) echo "selected"; ?>> Norveška</option>
                <option value="15"<?php if ($korisnik->adresa == 15) echo "selected"; ?>> Njemačka</option>
                <option value="16"<?php if ($korisnik->adresa == 16) echo "selected"; ?>> Poljska</option>
                <option value="17" <?php if ($korisnik->adresa == 17) echo "selected"; ?>v> Rusija</option>
                <option value="18"<?php if ($korisnik->adresa == 18) echo "selected"; ?>> Rumunjska</option>
                <option value="19"<?php if ($korisnik->adresa == 19) echo "selected"; ?>> Slovenija</option>
                <option value="20"<?php if ($korisnik->adresa == 20) echo "selected"; ?>> Srbija</option>
                <option value="21"<?php if ($korisnik->adresa == 21) echo "selected"; ?>> Španjolska</option>
                <option value="22"<?php if ($korisnik->adresa == 22) echo "selected"; ?>> Švedska</option>
            </select>

            <label class="mobilni" for="telefon">Mobilni telefon: </label>
            <input class="input3" type="tel" id="telefon" name="telefon" placeholder="xxx xxxxxxx"
                   value="<?php echo $korisnik->mobilni ?>">

            <br>
            <label class="email" for="email">E-mail adresa </label>
            <input class="input3" type="email" id="email" name="email" placeholder="korisnickoime@foi.hr"
                   value="<?php echo $korisnik->email ?>">
            <br>

            <p class="lokacija">Lokacija: </p>
            <label class="lokacija" for="lokacija"></label>
            <textarea id="lokacija" rows="40" cols="100" placeholder="Lokacija" name="lokacija" value="">
                <?php echo $korisnik->lokacija ?>
            </textarea>
            <br>
            <br>

            <label for="slika">Slika</label>
            <img
                src="https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcR2PemckC6zvQBLboPdZBZCJcnmQpo0oU5GQlb4XQvWAKcYvpdsutQfu84">
            <br>
            <br>
</div>

<footer>
    <a href="http://validator.w3.org/check?uri=http://barka.foi.hr/WebDiP/2015/zadaca_01/mzeleznj2/"><img
            src="img/HTML5.png" height="50" width="50" alt="valid_html"/></a>
    <a href="http://jigsaw.w3.org/css-validator/validator?uri=http://barka.foi.hr/WebDiP/2015/zadaca_01/mzeleznj2"><img
            src="img/CSS3.png" height="50" width="50" alt="valid_css"/> </a>
    <p> Vrijeme potrebno za izradu aktivnog dokumenta: 6h</p>
    <p>&copy; 2016 M.Zeleznjak</p>
</footer>
</body>
</html>