<?php

include 'baza_class.php';
include 'recaptha/recaptha.php';

$greske = [];

if (isset($_POST['registriraj'])) {
    if (provjeriSviUneseni()) {
        if (provjeriKorisnickoIme()) {
            if (provjeriLozinku()) {
                if (usporediLozinke()) {
                    if (provjeriGodine()) {
                        if (provjeriEmail()) {
                            if (provjeriLatLng()) {
                                if (provjeriZauzetost()) {
                                    if(provjeriRecaptha()){
                                        zapisiKorisnika();
                                        header("Location:prijava.php");
                                    } else {
                                        $greske[] = 'Rechapta nije ispravno unesena!';
                                    }
                                } else {
                                    $greske[] = 'Korisničko ili email su zauzeti!';
                                }
                            } else {
                                $greske[] = 'Format lokacije nije dobar!';
                            }
                        } else {
                            $greske[] = 'Format emaila nije dobar!';
                        }
                    } else {
                        $greske[] = 'Format godina ili mjeseci ili dana ne odgovara formatu!';
                    }
                } else {
                    $greske[] = 'Lozinke ne odgovaraju!';
                }
            } else {
                $greske[] = 'Lozinka ne odgovara zadanom formatu!';
            }
        } else {
            $greske[] = 'Korisnicko ime ne odgovara zadanom formatu!';
        }
    } else {
        $greske[] = 'Nisu uneseni svi potrebni podaci!';
    }
}

function provjeriSviUneseni()
{
    if (
        isset($_POST['ime']) && isset($_POST['prezime']) && isset($_POST['korime']) && isset($_POST['lozinka1'])
        && isset($_POST['lozinka2']) && isset($_POST['keygen']) && isset($_POST['danRod']) && isset($_POST['mjesec'])
        && isset($_POST['godina']) && isset($_POST['drzava']) && isset($_POST['telefon']) && isset($_POST['email'])
        && isset($_POST['robot']) && isset($_POST['lokacija']) && isset($_POST['obavijesti'])
    ) {
        return true;
    }
    return false;
}

function provjeriKorisnickoIme()
{
    $korime = $_POST['korime'];
    if (
        !empty($korime) && strlen($korime) >= 10 && is_string($korime)
        && (strtolower($korime[0]) == $korime[0]) && preg_match('/[A-Z]/', $korime)
    ) {
        return true;
    }
    return false;
}

function provjeriLozinku()
{
    $lozinka = $_POST['lozinka1'];

    if (!empty($lozinka) && strlen($lozinka) >= 8 && preg_match('/^(?=.*[a-zA-Z\d].*)[a-zA-Z\d!#?*]{8,}$/', $lozinka)) {
        return true;
    }
    return false;
}

function usporediLozinke()
{
    $lozinka1 = $_POST['lozinka1'];
    $lozinka2 = $_POST['lozinka2'];

    if ($lozinka1 == $lozinka2) {
        return true;
    }
    return false;
}

function provjeriGodine()
{
    $dan    = $_POST['danRod'];
    $mjesec = $_POST['mjesec'];
    $godina = $_POST['godina'];


    if ((int)$dan > 0 && (int)$mjesec > 0 && (int)$godina > 0 && (int)$godina >= 1930 && (int)$godina <= 2015) {
        return true;
    }
    return false;
}

function provjeriEmail()
{
    $email = $_POST['email'];
    if (preg_match('/^(?=.*[a-z0-9])[a-z0-9!@#$%&*.]{7,}$/', $email)) {
        return true;
    }

    return false;
}

function provjeriLatLng()
{
    $txt = $_POST['lokacija'];

    $re1 = '([+-]?\\d*\\.\\d+)(?![-+0-9\\.])';
    $re2 = '(;)';
    $re3 = '( )';
    $re4 = '([+-]?\\d*\\.\\d+)(?![-+0-9\\.])';

    if ($c = preg_match_all("/" . $re1 . $re2 . $re3 . $re4 . "/is", $txt, $matches)) {
        return true;
    }
    return false;
}

function provjeriZauzetost()
{
    $email  = $_POST['email'];
    $korime = $_POST['korime'];

    $upit = "SELECT * from korisnik WHERE korisnicko_ime='" . $korime . "' OR email='" . $email . "';";
    $baza = new Baza();
    $baza->spojiDB();

    $rezultat = $baza->selectDB($upit);
    $baza->zatvoriDB();

    if (mysqli_num_rows($rezultat) == 0) {
        return true;
    }

    return false;
}

function zapisiKorisnika()
{

    $baza = new Baza();
    $baza->spojiDB();

    $triSataOdSad    = (new DateTime())->modify('+3 hours')->format('Y-m-d h:m:s');
    $aktivacijskiKod = generirajAktivacijskiKod($_POST['korime']);
    posaljiAktivacijskiEmail($aktivacijskiKod);

    $upit = "
        INSERT INTO `WebDiP2015x092`.`korisnik`
        (`lozinka`, `ime`, `prezime`, `adresa`, `spol`, `email`, `id_tip_korisnika`, `korisnicko_ime`, `aktiviran`, `aktivacijski_kod`,`aktivacija_do`, `lokacija`, `mobilni`, `slika`, `obavijesti`, `keygen`)
        VALUES ('" . $_POST['lozinka1'] . "', '" . $_POST['ime'] . "','" . $_POST['prezime'] . "', '" . $_POST['drzava'] . "', '" . $_POST['spol'] . "', '" . $_POST['email'] . "', '3', '" . $_POST['korime'] . "', 0, '" . $aktivacijskiKod . "' ,'" . $triSataOdSad . "', '" . $_POST['lokacija'] . "', '" . $_POST['telefon'] . "', '', '" . $_POST['obavijesti'] . "', '" . $_POST['keygen'] . "');";

    $baza->updateDB($upit);

    $upitZadnjiKorisnik = "SELECT * from korisnik ORDER BY id DESC LIMIT 1";
    $rezultat           = $baza->selectDB($upitZadnjiKorisnik);
    $baza->zatvoriDB();

    $korisnik = [];
    if (!empty($rezultat) && mysqli_num_rows($rezultat) > 0) {
        $red      = mysqli_fetch_object($rezultat);
        $korisnik = ['korime' => $red->korisnicko_ime, 'id' => $red->id_korisnik, 'email' => $red->email];
    }
    return $korisnik;
}

function posaljiAktivacijskiEmail($kod)
{
    $link = 'https://barka.foi.hr/WebDiP/2015/zadaca_04/mzeleznj2/aktivacija.php?kod=' . $kod;
    mail($_POST['email'], 'Aktivacijski kod zadaca 4', $link);
    return $kod;
}

function generirajAktivacijskiKod($korime)
{
    $kod = (string)time() . $korime . 'webDip2016';
    return $kod;
}

?>

<!DOCTYPE html>
<html>
<head>
    <title> Zadaća 4 - Registracija</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Maja Zeleznjak">
    <meta name="keywords" content="FOI, WebDiP">
    <link rel="stylesheet" type="text/css" href="css/mzeleznj2.css"/>
    <script src='https://www.google.com/recaptcha/api.js'></script>
</head>
<body>
<section>
    <header>
        <h1> Zadaća 4</h1>
    </header>
</section>
<nav id="meni">
    <ul>
        <li>
            <a href="registracija.php">Registracija</a>
        </li>
        <li>
            <a href="prijava.php">Prijava</a>
        </li>
    </ul>
</nav>

<div class="div1">

    <form action="registracija.php" method="POST">
        <p class="naslov">Registracija novog korisnika</p><br>
        <label for="ime"> Ime </label>
        <input class="input2" type="text" id="ime" name="ime" placeholder="ime"><br>

        <label for="prezime">Prezime</label>
        <input class="input1" type="text" id="prezime" name="prezime" placeholder="Prezime"><br>

        <label for="korime">Korisničko ime</label>
        <input class="input3" type="text" id="korime" name="korime" placeholder="korime" autofocus="autofocus"><br>

        <label for="lozinka1">Lozinka: </label>
        <input class="input4" type="password" id="lozinka1" name="lozinka1" placeholder="lozinka"><br>

        <label for="lozinka2">Ponovi pozinku: </label>
        <input class="input5" type="password" id="lozinka2" name="lozinka2" placeholder="lozinka"><br> <br>

        <label class="labelae" for="keygen"> Enkripcija </label>
        <keygen name="keygen" id="keygen"><br>
            <br>
            <label class="datum">Datum rođenja: </label>
            <label for="danRod">Dan</label>

            <input type="number" name="danRod" id="danRod">

            <label for="mjesec">Mjesec</label>
            <select list="mjesec" name="mjesec" id="mjesec">
                <option value="1">Siječanj</option>
                <option value="2">Veljača</option>
                <option value="3">Ožujak</option>
                <option value="4">Travanj</option>
                <option value="5">Svibanj</option>
                <option value="6">Lipanj</option>
                <option value="7">Srpanj</option>
                <option value="8">Kolovoz</option>
                <option value="9">Rujan</option>
                <option value="10">Listopad</option>
                <option value="11">Studeni</option>
                <option value="12">Prosinac</option>
            </select>

            <label for="godina">Godina</label>
            <input type="number" name="godina" id="godina"> <br>

            <label class="spol" for="spol">Spol: </label>
            <select id="spol" name="spol">
                <option value="-1" selected="selected">Odaberi spol</option>
                <option value="M">Muškarac</option>
                <option value="Z">Žena</option>
            </select><br>

            <label class="drzava" for="drzava"> Država </label>
            <select id="drzava" name="drzava">
                <option value="-1" selected="selected"> Odaberi drzavu</option>
                <option value="1"> Alžir</option>
                <option value="2"> Austrija</option>
                <option value="3"> Bosna i Hercegovina</option>
                <option value="4"> Bugarska</option>
                <option value="5"> Crna Gora</option>
                <option value="6"> Čile</option>
                <option value="7"> Dominikanska republika</option>
                <option value="8"> Etiopija</option>
                <option value="9"> Francuska</option>
                <option value="10"> Fidži</option>
                <option value="11"> Gana</option>
                <option value="12"> Hrvatska</option>
                <option value="13"> Makedonija</option>
                <option value="14"> Norveška</option>
                <option value="15"> Njemačka</option>
                <option value="16"> Poljska</option>
                <option value="17"> Rusija</option>
                <option value="18"> Rumunjska</option>
                <option value="19"> Slovenija</option>
                <option value="20"> Srbija</option>
                <option value="21"> Španjolska</option>
                <option value="22"> Švedska</option>
            </select>

            <label class="mobilni" for="telefon">Mobilni telefon: </label>
            <input class="input3" type="tel" id="telefon" name="telefon" placeholder="xxx xxxxxxx">

            <br>
            <label class="email" for="email">E-mail adresa </label>
            <input class="input3" type="email" id="email" name="email" placeholder="korisnickoime@foi.hr">
            <br>

            <label class="robot" for="robot">Dokazite da niste robot </label>
            <input type="checkbox" id="robot" name="robot" value="robot"><br>
            <br>

            <p class="lokacija">Lokacija: </p>
            <label class="lokacija" for="lokacija"></label>
            <textarea id="lokacija" rows="40" cols="100" placeholder="Lokacija" name="lokacija"></textarea>
            <br>
            <br>

            <label for="slika">Slika</label>
            <input name="slika" type="file" id="slika">
            <br>
            <br>

            <label class="label2" for="obavijesti">Želite li primati obavijesti?</label>
            <input type="radio" name="obavijesti" value="Ne primaj" id="obavijesti1"/>
            <label for="obavijesti">Ne </label>
            <input type="radio" id="obavijesti" name="obavijesti" value="Primaj"/>
            <label for="obavijesti">Da</label><br>

            <br>
            <div class="g-recaptcha" data-sitekey="6Leb7h4TAAAAALvUW1yxckRyPN6d9_4-4LJudwyc"></div>

            <br>
            <input type="submit" name="registriraj" value="Registriraj se"/>
            <input type="reset" value="Reseritaj"> <br>

            <p class="greske">
                <?php
                foreach ($greske as $greska) {
                    echo $greska . '<br>';
                }
                ?>
            </p>
    </form>
</div>

<footer>
    <a href="http://validator.w3.org/check?uri=http://barka.foi.hr/WebDiP/2015/zadaca_01/mzeleznj2/">
        <img src="img/HTML5.png" height="50" width="50" alt="valid_html"/></a>
    <a href="http://jigsaw.w3.org/css-validator/validator?uri=http://barka.foi.hr/WebDiP/2015/zadaca_01/mzeleznj2">
        <img src="img/CSS3.png" height="50" width="50" alt="valid_css"/> </a>
    <p> Vrijeme potrebno za izradu aktivnog dokumenta: 16h</p>
    <p>&copy; 2016 M.Zeleznjak</p>
</footer>
</body>
</html>