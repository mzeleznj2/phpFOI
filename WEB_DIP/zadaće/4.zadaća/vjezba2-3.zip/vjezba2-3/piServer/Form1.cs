﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using SeMiscLibrary;
namespace piServer
{
    public partial class Form1 : Form
    {
        ServerLogika server;
        Operations o = new Operations();
        public Form1()
        {
            InitializeComponent();
            server = new ServerLogika(ReceiveContainer);
        }
        private void StartListeningAction_Click(object sender, EventArgs e)
        {
            server.pokretanjeServera();
        }

        private void ServerStop_Click(object sender, EventArgs e)
        {
            server.ZaustavljanjeServera();
        }
    }
}