﻿namespace piServer
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.StartListeningAction = new System.Windows.Forms.Button();
            this.ReceiveContainer = new System.Windows.Forms.TextBox();
            this.ServerStop = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // StartListeningAction
            // 
            this.StartListeningAction.Location = new System.Drawing.Point(18, 101);
            this.StartListeningAction.Name = "StartListeningAction";
            this.StartListeningAction.Size = new System.Drawing.Size(105, 23);
            this.StartListeningAction.TabIndex = 8;
            this.StartListeningAction.Text = "Pokreni server";
            this.StartListeningAction.UseVisualStyleBackColor = true;
            this.StartListeningAction.Click += new System.EventHandler(this.StartListeningAction_Click);
            // 
            // ReceiveContainer
            // 
            this.ReceiveContainer.Location = new System.Drawing.Point(12, 22);
            this.ReceiveContainer.Multiline = true;
            this.ReceiveContainer.Name = "ReceiveContainer";
            this.ReceiveContainer.Size = new System.Drawing.Size(251, 73);
            this.ReceiveContainer.TabIndex = 6;
            // 
            // ServerStop
            // 
            this.ServerStop.Location = new System.Drawing.Point(158, 101);
            this.ServerStop.Name = "ServerStop";
            this.ServerStop.Size = new System.Drawing.Size(105, 23);
            this.ServerStop.TabIndex = 9;
            this.ServerStop.Text = "Isključi server";
            this.ServerStop.UseVisualStyleBackColor = true;
            this.ServerStop.Click += new System.EventHandler(this.ServerStop_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(277, 135);
            this.Controls.Add(this.ServerStop);
            this.Controls.Add(this.StartListeningAction);
            this.Controls.Add(this.ReceiveContainer);
            this.Name = "Form1";
            this.Text = "PI server";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button StartListeningAction;
        private System.Windows.Forms.TextBox ReceiveContainer;
        private System.Windows.Forms.Button ServerStop;
        private System.Windows.Forms.Timer timer1;
    }
}

