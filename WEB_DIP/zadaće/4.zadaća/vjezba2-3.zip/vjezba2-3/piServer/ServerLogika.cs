﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using SeMiscLibrary;
using System.Threading;
using System.Drawing;

namespace piServer
{
    class ServerLogika
    {
        //Interna mreža, prenose se data grami, a korisnti se protokol udp
        private Socket soket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
        private SocketAsyncEventArgs poruka = new SocketAsyncEventArgs();
        //max. veličina spremnika
        private byte[] spremnik = new byte[1024];
        private TextBox t;
        Operations o = new Operations();
        Thread t1;

        public ServerLogika(TextBox o)
        {
            t = o;
            soket.ExclusiveAddressUse = false;
            poruka.Completed += poruka_Completed;
            poruka.SetBuffer(spremnik, 0, 1024);
        }

        public void poruka_Completed(object sender, SocketAsyncEventArgs e)
        {
            //događaj koji se okida kada se dođe poruka
            if(soket != null)
            {
                if (poruka.LastOperation == SocketAsyncOperation.Receive)
                {
                    Pisi("Poruka: " + UTF8Encoding.UTF8.GetString(poruka.Buffer, 0, e.BytesTransferred));
                    soket.ReceiveAsync(poruka);
                }
            }
            
        }

        public void Pisi(string message)
        {
            t.Invoke((MethodInvoker)delegate
            {
                t.Text += message + Environment.NewLine;
            });
        }

        public void postavljanje()
        {
            /*if(soket == null)
            {
                soket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
            }*/
            //zbog postavki servera nije moguce vise puta paliti i gasiti vezu
            if(soket != null)
            {
                t.Invoke((MethodInvoker)delegate
                {
                    if (soket.IsBound == false)
                    {
                        //soket se spaja na port
                        soket.Bind(new IPEndPoint(IPAddress.Any, 8087));
                        //pokreće se primanje poruka
                        soket.ReceiveAsync(poruka);
                        Pisi("Aktiviran server");
                    }
                    else
                    {
                        Pisi("Server je pokrenut");
                    }
                });
            }else
            {
                //nije moguće uspostaviti više od jedne veze
                Socket soket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
                //soket se spaja na port
                soket.Bind(new IPEndPoint(IPAddress.Any, 8087));
                //pokreće se primanje poruka
                soket.ReceiveAsync(poruka);
                Pisi("Aktiviran server");
            }
            
        }

        public void pokretanjeServera()
        {
            t1 = new Thread(new ThreadStart(postavljanje));
            t1.Start();
        }

        public void ZaustavljanjeServera() {
            
            soket.Close();
            soket = null;
            Pisi("Zaustavljen server");
        }
    }
}
