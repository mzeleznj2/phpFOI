﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Windows.Forms;

namespace piClient
{
    public partial class Form1 : Form
    {

        KlijentLogika klijent;
        public Form1()
        {
            InitializeComponent();
            klijent = new KlijentLogika(ReceiveContainer);
            //this.AcceptButton = MessageSendAction;
        }
        private void MessageSendAction_Click(object sender, EventArgs e)
        {
            klijent.SlanjePoruke(MessageToSend.Text);
            klijent.OcistiUnos(MessageToSend);
            klijent.Pisi("message sent");
        }
        private void DestinationSetAction_Click(object sender, EventArgs e)
        {
            klijent.PostaviOdrediste(klijent.DohvatiAdresu(DestinationAddress));
        }
    }
}