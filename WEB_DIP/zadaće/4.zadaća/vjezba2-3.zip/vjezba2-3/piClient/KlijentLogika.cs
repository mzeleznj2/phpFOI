﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.Windows.Forms;

namespace piClient
{
    class KlijentLogika
    {
        private Socket soket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
        private SocketAsyncEventArgs poruka = new SocketAsyncEventArgs();
        private byte[] spremnik = new byte[1024];
        private TextBox t;
        private bool pomoc = false;

        public KlijentLogika(TextBox o)
        {
            t = o;
            //zabranjuju se eksluzivne adrese 
            soket.ExclusiveAddressUse = false;
            //dodaje se event kada se izvrši slanje poruke
            poruka.Completed += poruka_Completed;
            //postavlja se veličina buffera->najveća moguća poruka
            poruka.SetBuffer(spremnik, 0, 1024);
        }

        public void poruka_Completed(object sender, SocketAsyncEventArgs e)
        {
            //ako je zadnje izvršeno slanje, ispisuje koja poruka je otišla i gdje
            if (poruka.LastOperation == SocketAsyncOperation.SendTo)
            {
                Pisi("Odredište: " + poruka.RemoteEndPoint.ToString() + " poruka: " + UTF8Encoding.UTF8.GetString(poruka.Buffer, 0, e.BytesTransferred));
            }
        }

        public void Pisi(string tekst)
        {
            t.Invoke((MethodInvoker)delegate
            {
                t.Text += tekst + Environment.NewLine;
            });
        }

        public IPEndPoint DohvatiAdresu(MaskedTextBox o)
        {
            //pronalazi koja je IP adresa unesena
            if (o.Text.Replace(" ", "") == "127.000.000.001")
                pomoc = true;
            if (o.Text.Replace(" ", "") == "000.000.000.000")
            {
                pomoc = true;
                o.Text = "127.000.000.001";
                MessageBox.Show("Umjeso adrese 0.0.0.0 postavljena je defaultna adresa 127.000.000.001");
            }
            return new IPEndPoint(IPAddress.Parse(o.Text.Replace(" ", "")), 8087);
        }

        public void PostaviOdrediste(IPEndPoint adresa)
        {
            //radnje koje je potreno izvesti za unesenu IP adresu
            if (pomoc)
            {
                poruka.RemoteEndPoint = adresa;
                Pisi("Odredišna adresa postavljena je na: " + poruka.RemoteEndPoint.ToString());
            }
            else{
                MessageBox.Show("Jedina moguća adresa je lokalna adresa(127.000.000.001. Postavite tu adresu kako bi omogučili komunikaciju");
            }
        }

        public void SlanjePoruke(string p)
        {
            //pretvaranje znakova u bytove
            spremnik = UTF8Encoding.UTF8.GetBytes(p);
            //postavljanje veličine buffera(veličina poruke)
            poruka.SetBuffer(spremnik, 0, spremnik.Length);
            //slanje poruke preko soketa
            soket.SendToAsync(poruka);    
        }

        public void OcistiUnos(TextBox o)
        {
            o.Clear();
        }
    }
}