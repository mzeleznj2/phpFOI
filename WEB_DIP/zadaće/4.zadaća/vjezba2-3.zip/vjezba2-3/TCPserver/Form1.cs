﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
namespace TCPserver
{
    public partial class Form1 : Form
    {
        private Socket netSocket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
        private SocketAsyncEventArgs netSocketServerArgs = new SocketAsyncEventArgs();
        private byte[] netBuffer = new byte[1024];
        public Form1()
        {
            InitializeComponent();
            netSocket.ExclusiveAddressUse = false;
            netSocketServerArgs.Completed += netSocketServerArgs_Completed;
            netSocketServerArgs.SetBuffer(netBuffer, 0, 1024);
        }
        private void netSocketServerArgs_Completed(object send, SocketAsyncEventArgs e)
        {
            if(netSocketServerArgs.LastOperation == SocketAsyncOperation.Receive)
            {
                pisiPoruke("Poruka: " + UTF8Encoding.UTF8.GetString(netSocketServerArgs.Buffer, 0, e.BytesTransferred));
                netSocket.ReceiveAsync(netSocketServerArgs);
            }
        }
        private void pocniSlusati()
        {
            netSocket.Bind(new IPEndPoint(IPAddress.Any, 8087));
            netSocket.ReceiveAsync(netSocketServerArgs);
            pisiPoruke("Serever aktivno sluša");
        }
        private void pisiPoruke(string poruka)
        {
            PorukeServera.Invoke((MethodInvoker)delegate
            {
                PorukeServera.Text += poruka + Environment.NewLine;
            });
        }

        private void StartServera_Click(object sender, EventArgs e)
        {
            pocniSlusati();
        }
    }
}
