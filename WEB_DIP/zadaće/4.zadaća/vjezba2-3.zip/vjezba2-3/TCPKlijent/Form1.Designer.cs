﻿namespace TCPKlijent
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.Odrediste = new System.Windows.Forms.MaskedTextBox();
            this.Postavi = new System.Windows.Forms.Button();
            this.Poruke = new System.Windows.Forms.TextBox();
            this.Tekst = new System.Windows.Forms.TextBox();
            this.lbl = new System.Windows.Forms.Label();
            this.Posalji = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Odredište:";
            // 
            // Odrediste
            // 
            this.Odrediste.Location = new System.Drawing.Point(73, 6);
            this.Odrediste.Mask = "000.000.000.000";
            this.Odrediste.Name = "Odrediste";
            this.Odrediste.Size = new System.Drawing.Size(128, 20);
            this.Odrediste.TabIndex = 1;
            this.Odrediste.Text = "000000000000";
            // 
            // Postavi
            // 
            this.Postavi.Location = new System.Drawing.Point(220, 4);
            this.Postavi.Name = "Postavi";
            this.Postavi.Size = new System.Drawing.Size(75, 23);
            this.Postavi.TabIndex = 2;
            this.Postavi.Text = "Postavi";
            this.Postavi.UseVisualStyleBackColor = true;
            // 
            // Poruke
            // 
            this.Poruke.Location = new System.Drawing.Point(12, 32);
            this.Poruke.Multiline = true;
            this.Poruke.Name = "Poruke";
            this.Poruke.Size = new System.Drawing.Size(362, 184);
            this.Poruke.TabIndex = 3;
            // 
            // Tekst
            // 
            this.Tekst.Location = new System.Drawing.Point(73, 223);
            this.Tekst.Name = "Tekst";
            this.Tekst.Size = new System.Drawing.Size(172, 20);
            this.Tekst.TabIndex = 4;
            // 
            // lbl
            // 
            this.lbl.AutoSize = true;
            this.lbl.Location = new System.Drawing.Point(23, 226);
            this.lbl.Name = "lbl";
            this.lbl.Size = new System.Drawing.Size(44, 13);
            this.lbl.TabIndex = 5;
            this.lbl.Text = "Poruka:";
            // 
            // Posalji
            // 
            this.Posalji.Location = new System.Drawing.Point(266, 221);
            this.Posalji.Name = "Posalji";
            this.Posalji.Size = new System.Drawing.Size(75, 23);
            this.Posalji.TabIndex = 6;
            this.Posalji.Text = "Pošalji";
            this.Posalji.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(386, 261);
            this.Controls.Add(this.Posalji);
            this.Controls.Add(this.lbl);
            this.Controls.Add(this.Tekst);
            this.Controls.Add(this.Poruke);
            this.Controls.Add(this.Postavi);
            this.Controls.Add(this.Odrediste);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MaskedTextBox Odrediste;
        private System.Windows.Forms.Button Postavi;
        private System.Windows.Forms.TextBox Poruke;
        private System.Windows.Forms.TextBox Tekst;
        private System.Windows.Forms.Label lbl;
        private System.Windows.Forms.Button Posalji;
    }
}

