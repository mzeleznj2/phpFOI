﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
namespace TCPKlijent
{
    public partial class Form1 : Form
    {
        private Socket netSocket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
        private SocketAsyncEventArgs netSocketClientArgs = new SocketAsyncEventArgs();
        private byte[] netSocketBuffer = new byte[1024];

        public Form1()
        {
            InitializeComponent();
            netSocket.ExclusiveAddressUse = false;
            netSocketClientArgs.Completed += netSocketClientArgs_Completed;
            netSocketClientArgs.SetBuffer(netSocketBuffer, 0, 1024);
            this.AcceptButton = Postavi;
        }

        void netSocketClientArgs_Completed(object sender, SocketAsyncEventArgs e)
        {
            if (netSocketClientArgs.LastOperation == SocketAsyncOperation.SendTo)
            {
                WriteToLog("destination: " + netSocketClientArgs.RemoteEndPoint.ToString() + " message: " + UTF8Encoding.UTF8.GetString(netSocketClientArgs.Buffer, 0, e.BytesTransferred));
            }
        }
        private void WriteToLog(string message)
        {
            Poruke.Invoke((MethodInvoker)delegate
            {
                Poruke.Text = message + Environment.NewLine + Poruke.Text;
            });
        }
        private IPEndPoint GetDestination()
        {
            return new IPEndPoint(IPAddress.Parse(Odrediste.Text.Replace(" ", "")), 8087);
        }
        private void DestinationSet(IPEndPoint address)
        {
            netSocketClientArgs.RemoteEndPoint = address;
            WriteToLog("destination set to: " + netSocketClientArgs.RemoteEndPoint.ToString());
        }
        private void MessageSend(string message)
        {
            netSocketBuffer = UTF8Encoding.UTF8.GetBytes(message);
            netSocketClientArgs.SetBuffer(netSocketBuffer, 0, netSocketBuffer.Length);
            netSocket.SendToAsync(netSocketClientArgs);
        }

        private void ClearMessageInput()
        {
            Tekst.Clear();
        }
        private void Posalji_Click(object sender, EventArgs e)
        {
            MessageSend(Tekst.Text);
            ClearMessageInput();
            WriteToLog("message sent");
        }
        private void Postavi_Click(object sender, EventArgs e)
        {
            DestinationSet(GetDestination());
        }
    }
}
