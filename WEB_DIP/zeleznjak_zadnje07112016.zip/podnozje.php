﻿<footer id="footer">
    <a href="http://validator.w3.org/check?uri=http://barka.foi.hr/WebDiP/2015/zadaca_01/mzeleznj2/"><img
            src="./img/HTML5.png" height="50" width="50" alt="valid_html"/></a>
    <a href="http://jigsaw.w3.org/css-validator/validator?uri=http://barka.foi.hr/WebDiP/2015/zadaca_01/mzeleznj2"><img
            src="./img/CSS3.png" height="50" width="50" alt="valid_css"/> </a>
    <p> Vrijeme potrebno za izradu aktivnog dokumenta: 8h</p>
    <p>&copy; 2016 M.Zeleznjak</p>
</footer>
</body>
</html>